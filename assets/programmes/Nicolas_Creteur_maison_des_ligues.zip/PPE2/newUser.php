<?php  

  // Verification de création de compte //

    // test si un champs est vide //
    if(isset($_POST["Nom1"]) ||
      isset($_POST["Prénom1"]) ||
      isset($_POST["Email1"]) ||
      isset($_POST["Login1"]) ||
      isset($_POST["password1"]) ||
      isset($_POST["password2"])){

      // test si tout les champs sonts remplis //
      if(!empty($_POST["Nom1"])&&
        !empty($_POST["Prénom1"])&&
        !empty($_POST["Email1"])&&
        !empty($_POST["Login1"])&&
        !empty($_POST["password1"])&&
        !empty($_POST["password2"])){

        // test si les champs des deux MDP sont identiques //
        if($_POST["password1"] === $_POST["password2"]){

          // test si le login utiliser n'existe pas //
          include_once "connexion_BDD.php";
          $login1 = $_POST["Login1"]; 
          $req = $pdo->prepare('SELECT * FROM users WHERE login=(:login1)');
          $req->execute([
          'login1' => $login1
          ]);
          $pass = $req->fetchAll(PDO::FETCH_ASSOC);
          $tabmdp = ['pass'=>$pass];
          $b = $pass[0];

          // test si l'email utiliser n'existe pas //
          include_once "connexion_BDD.php";
          $email1 = $_POST["Email1"]; 
          $req1 = $pdo->prepare('SELECT * FROM users WHERE email=(:email1)');
          $req1->execute([
          'email1' => $email1
          ]);
          $pass1 = $req1->fetchAll(PDO::FETCH_ASSOC);
          $tabmdp1 = ['pass1'=>$pass1];
          $b1 = $pass1[0];

          // création d'un nouveau user //
          if(($login1 !== $b["login"]) && ($email1 !== $b1["email"])){
            $nom = $_POST["Nom1"];
            $prenom = $_POST["Prénom1"];
            $email = $_POST["Email1"];
            $login = $_POST["Login1"];
            $password = $_POST["password1"];
            include_once "connexion_BDD.php";  
            $req = $pdo->prepare('INSERT INTO users(nom,prenom,email,login,password) 
              VALUES (:nom, :prenom, :email, :login, :password)');
            $req->execute([
              'nom' => $nom,
              'prenom' => $prenom,
              'email' => $email,
              'login' => $login,
              'password' => $password
            ]);

            // Message erreurs //
            $erreur = 7;
          }
          else{
            $erreur = 6;
          }
        }
        else{
          $erreur = 5;
        }
      }
      else{
        $erreur = 4;
      }

      // Fin message erreurs //
    }

  // Fin verification de création de compte //

?>