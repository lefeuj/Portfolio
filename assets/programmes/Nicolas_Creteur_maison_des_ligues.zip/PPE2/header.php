<?php

  // Chargement Des Pages //

  include_once "auth.php";
  include_once "functions.php";

  // Fin Chargement Des Pages //

?>

<!DOCTYPE html>
<html lang="fr">
  <!-- Section Header -->
  
  <head>

    <meta charset="utf-8">
    <title><?= titreDeLaPage();?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="navbar-top-fixed.css" rel="stylesheet">
    <style>
      img{
        display:block;
        margin:auto;
        width: 150px;
      }
      body {
        background-color:whitesmoke;
      }
    </style>

  </head>

  <!-- Fin Section Header -->
  
  <!-- Section Body Navigation -->

  <body>

    <!-- Section Navigation -->

    <nav class="navbar navbar-expand-md navbar-dark mb-4 bg-dark">

        <div class="container-fluid">
            <a class="navbar-brand">M2L</a>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <!-- Section Menu -->
                <ul class="navbar-nav me-auto mb-2 mb-md-0">
                    <?= btnNavigation("index") ?>
                    <?= btnNavigation("article") ?>
                    <?= btnNavigation("resultat") ?>
                    <?= btnNavigation("presentation") ?>
                    <?= btnNavigationPrivée()?>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <?= btnLoginLogout() ?>
                </ul>
                <!-- Fin Section Menu -->
            </div>
        </div>

    </nav>

    <!-- Fin Section Navigation -->

    <script 
      src="/docs/5.1/dist/js/bootstrap.bundle.min.js" 
      integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" 
      crossorigin="anonymous">
    </script>

  </body>

  <!-- Fin Section Body Navigation -->