<?php 

  // Chargement Des Pages //

  include_once "header.php";
  include_once "auth.php";
  $erreur = null;
  include_once "testId.php";
  include_once "newUser.php";

  // Fin Chargement Des Pages //
?>

<!-- Section Body Page De Connection -->

<body>
  
  <div class ="row" style="height:80%;">

    <!-- Section Formulaire de connection -->

    <div class ="col-6" style="border-right:2px solid black;width:49.6%">
      <h4>Connectez-vous</h4>
      </br>
      <form action="" method="post">
        <?= formulaireInput("Login",0) ?>
        <div class ="form-group">
          <input type="password" name="password" placeholder="password">
        </div>
        <button type="submit" class = "btn btn-success">Se connecter</button>
      </form>
    </div>

    <!-- Fin Section Formulaire de connection -->

    <!-- Section Formulaire création de compte -->

    <div class ="col-6"style="border-left: 2px solid black;width:49.6%">
      <h4>Enregistrez-vous</h4>
      </br>
      <form action="" method="post">
        <?= formulaireInput("Nom1","Nom") ?>
        <?= formulaireInput("Prénom1","Prenom") ?>
        <?= formulaireInput("Email1","Email") ?>
        <?= formulaireInput("Login1","Login") ?>
        <?= formulaireInput("password1","Mot de passe") ?>
        <?= formulaireInput("password2","Confirmer votre mot de passe") ?>
        <button type="submit" class = "btn btn-success " style>S'enregistrer</button>
      </form>
    </div>

    <!-- Fin Section Formulaire création de compte -->

  </div>

  <!-- Message d'erreur -->
  <?= erreurLogin($erreur) ?>

</body>

<!-- Fin Section Body Page De Connection -->

<!-- Section Footer -->

<?php include_once "footer.php" ?>

<!-- Fin Section Footer -->