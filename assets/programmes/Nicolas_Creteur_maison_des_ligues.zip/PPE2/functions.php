<?php
    // Function Authentification //

        // Function Modifier Tableau utilisateur dans Dashboard //
        function tabModif($x,$a){
            $id = $_POST["Modifier"];
            include("connexion_BDD.php");
            $q = $pdo->prepare('SELECT * FROM score WHERE id=(:id)');
            $q->execute([
                'id' => $id
            ]);
            $listeUsers = $q->fetchAll(PDO::FETCH_ASSOC);
            $b = $listeUsers[0];
            if($a === null){
                $y = 0;
                while($y != $x){
                    $y += 1;
                    echo <<<HTML
                        <th style ="border:1px solid; width:30px;">$y</th>
                    HTML;
                }
            }
            if($a === "tab-aller"){
                $y = 0;
                while($y != $x){
                    $y += 1;
                    $point = $b["aller_$y"];
                    echo <<<HTML
                        <td style ="border:1px solid; width:55px;">
                            <div class="form-group">
                                <input class="form-control" type="text" name= "aller_$y" value= $point>
                            </div>
                        </td>
                    HTML;
                }
            }
            if($a === "tab-retour"){
                $y = 0;
                while($y != $x){
                    $y += 1;
                    $point = $b["retour_$y"];
                    echo <<<HTML
                        <td style ="border:1px solid; width:55px;">
                            <div class="form-group">
                                <input class="form-control" type="text" name= "retour_$y" value= $point>
                            </div>
                        </td>
                    HTML;
                }
            }
        }

        // Modifie le titre en fonction de la page //
        function titreDeLaPage(){
            if($_SERVER['SCRIPT_NAME'] === "/index.php"){
                echo "Page d'Accueil";
            }
            else{
                $x = str_replace(["/",".php"], "", $_SERVER["SCRIPT_NAME"]);
                echo ucfirst($x);
            }
        }

        // Nome le boutton en fonction du nom de la page // 
        function btnNavigation($x){
            $active = null;
            if($_SERVER['SCRIPT_NAME'] === "/$x.php"){
                $active = "active";
            }
            if($x === "index"){
                return <<<HTML
                    <li class="nav-item">
                        <a class="nav-link $active"  href="$x.php">Accueil</a>
                    </li>
                HTML;
            }
            if($x === "login"){
                return <<<HTML
                    <li class="nav-item">
                        <a class="nav-link $active"  href="$x.php">Se connecter</a>
                    </li>
                HTML;
            }
            if($x === "logout"){
                return <<<HTML
                    <li class="nav-item">
                        <a class="nav-link $active"  href="$x.php">Se déconnecter</a>
                    </li>
                HTML;
            }
            else{
                $y = ucfirst($x);
                return <<<HTML
                    <li class="nav-item">
                        <a class="nav-link $active"  href="$x.php">$y</a>
                    </li>
                HTML;
            }
        }

        // Fonction raccourcis de formulaire //
        function formulaireInput($w,$x){
            if($x === 0){
                $x = $w;
            }
            return <<<HTML
                <div class="form-group">
                    <input type="text" name="$w" placeholder="$x">
                </div>
            HTML;
        }

        // Message d'erreurs de Login et MDP //
        function erreurLogin($x){
            if($x == 1){
                $y = "danger";
                $z = "Identifiant ou mdp incorect";
            }
            if($x == 2){
                $y = "warning";
                $z = "Votre compte a temporairement été suspendu , veuillez vous tourner vers l'administrateur ";
            }
            if($x == 3){
                $y = "success";
                $z = "Votre compte est en cours de validation, merci de patienter";
            }
            if($x == 4){
                $y = "warning";
                $z = "Attention , tous les champs doivent etre remplis";
            }
            if($x == 5){
                $y = "warning";
                $z = "Attention , les mot de passe 1 et 2 doivent etre identiques ";
            }
            if($x == 6){
                $y = "danger";
                $z = "Ce compte est déjà utilisé";
            }
            if($x == 7){
                $y = "success";
                $z = "Votre compte à bien été créer , vous pourez utiliser votre compte quand l'administrateur l'aura valider";
            }
            return <<<HTML
            <div class="alert alert-$y">$z</div>
            HTML;
        }

        // Fonction titre de Tableau //
        function td($x,$y){
            if($y === 0){
                echo <<<HTML
                    <td style ="border:1px solid">$x</td>
                HTML;
            }
            if($y === 1){
                echo <<<HTML
                    <td style ="border:1px solid">
                        <strong>
                            $x
                        </strong>
                    </td>
                HTML;
            }
        }

        // Function ligne de tableau //
        function th($x,$y,$z){
            $x = ucfirst($x);
            $y = ucfirst($y);
            $z = ucfirst($z);
            echo <<<HTML
                <tr>
                    <th style ="border:1px solid">$y</th>
                    <th style ="border:1px solid">$z</th>
                </tr>
            HTML;
        }

        // Bouton Accepter, Supprimer, Suspendre, Reprendre un User//
        function btnAccepteSuprimeUser($x,$z){
            if($z === "Supprimer" || $z === "Refuser"){
                $y = "btn btn-outline-danger";
            }
            if($z === "Accepter"){
            $y = "btn btn-outline-success";
            }
            if($z === "Reprendre"){
            $y = "btn btn-outline-primary";
            }
            if($z === "Suspendre"){
            $y = "btn btn-outline-warning";
            }
            return <<<HTML
            <form action="" style ="margin-bottom:1px"method="post">
            <input hidden  type="text" name = "$z" value = "$x" >
            <button type="submit" class = "$y" style>$z</button>
            </form>
            HTML;
        }

        // Modification dans la BDD des champs des Users //
        function validateDeleteUser($pdo){
            if(isset($_POST["Accepter"])){
                $valeur = $_POST["Accepter"];
                $s = 'UPDATE users SET valider="1" WHERE id =(:id)';
            }
            if(isset($_POST["Supprimer"]) || isset($_POST["Refuser"])){
                if(isset($_POST["Supprimer"])){
                    $valeur = $_POST["Supprimer"];
                }
                if(isset($_POST["Refuser"])){
                    $valeur = $_POST["Refuser"];
                }
                $s = 'DELETE FROM users WHERE id =(:id) LIMIT 1';
            }
            if(isset($_POST["Suspendre"])){
                $valeur = $_POST["Suspendre"];
                $s = 'UPDATE users SET pause="1" WHERE id =(:id)';
            }
            if(isset($_POST["Reprendre"])){
                $valeur = $_POST["Reprendre"];
                $s = 'UPDATE users SET pause="0" WHERE id =(:id)';
            }
            $MAJ = $pdo->prepare($s);
            if($valeur != null){
            $MAJ->execute([
                'id' => $valeur
            ]);
            }
        }

        // Afficher le tableau des users //
        function tableauUsers($nbUsers,$listeUsers,$x){
            $a = 0;
            $nbx = $nbUsers[0];
            while($a < $nbx){
                if($listeUsers[$a]["admin"]!== "1"){
                    if($x === "Accepter"){
                        if($listeUsers[$a]["valider"]!== "1"){
                            echo"<tr>";
                            td($listeUsers[$a]["nom"],0);
                            td($listeUsers[$a]["prenom"],0);
                            td($listeUsers[$a]["email"],0);
                            td(btnAccepteSuprimeUser($listeUsers[$a]["id"],"Accepter"),0);
                            td(btnAccepteSuprimeUser($listeUsers[$a]["id"],"Refuser"),0);
                            echo"</tr>";
                            $a += 1;
                        }
                        else{
                            $a += 1;
                        }
                    }
                    if($x === "Supprimer"){
                        if($listeUsers[$a]["valider"]=== "1"){
                            echo"<tr>";
                            td($listeUsers[$a]["nom"],0);
                            td($listeUsers[$a]["prenom"],0);
                            td($listeUsers[$a]["email"],0);
                            if($listeUsers[$a]["pause"]==="0"){
                                td(btnAccepteSuprimeUser($listeUsers[$a]["id"],"Suspendre"),0);
                            }
                            if($listeUsers[$a]["pause"]==="1"){
                                td(btnAccepteSuprimeUser($listeUsers[$a]["id"],"Reprendre"),0);
                            }
                            td(btnAccepteSuprimeUser($listeUsers[$a]["id"],"Supprimer"),0);
                            echo"</tr>";
                            $a += 1;
                        }
                        else{
                            $a += 1;
                        }
                    }

                }
                else{
                $a += 1;
                }
            }
        }

        // Recuperer une image stocker dans la BDD //
        function image($x){
            include("connexion_BDD.php");
            $a = $pdo->prepare('SELECT * FROM images WHERE id='.$x.' limit 1');
            $a->setFetchMode(PDO::FETCH_ASSOC);
            $a->execute($_GET["id"]);
            $b = $a->fetch();
            $result = base64_encode($b['image']);
            return <<<HTML
                <img src="data:image/jpeg;base64,$result"/>
            HTML;
        }

        // Afficher le Tableau des equipes //
        function tableauEquipe(){
            include("connexion_BDD.php");
            $q = $pdo->prepare('SELECT * FROM images');
            $q->execute();
            $f = $pdo->prepare('SELECT COUNT(*) FROM images');
            $f->execute();
            $listeUsers = $q->fetchAll(PDO::FETCH_ASSOC);
            $nbUsers = $f->fetchAll(PDO::FETCH_COLUMN);
            $a = 0;
            $nbx = $nbUsers[0];
            while($a < $nbx){
                echo"<tr>";
                td(image($listeUsers[$a]["id"]),0);
                td($listeUsers[$a]["equipe"],1);
                td($listeUsers[$a]["entraineur"],1);
                td($listeUsers[$a]["info"],0);
                echo"</tr>";
                $a += 1;
            }
        }

        // Afficher le total des points //
        function tabTotal(){
            include("connexion_BDD.php");
            $q = $pdo->prepare('SELECT * FROM score');
            $q->execute();
            $f = $pdo->prepare('SELECT COUNT(*) FROM score');
            $f->execute();
            $listeUsers = $q->fetchAll(PDO::FETCH_ASSOC);
            $nbUsers = $f->fetchAll(PDO::FETCH_COLUMN);
            $a = 0;
            $nbx = $nbUsers[0];
            echo <<<HTML
                <table>
                    <thead>
                        <tr>
                            <th style ="border:2px solid; text-align:center"colspan ="2">Resultat</th>
                        </tr>
                        <tr>
                            <th style ="border:1px solid; width:250px;">Equipe</th>
                            <th style ="border:1px solid; width:150px;">Total des points</th>
                        </tr>
                    </thead>
                    <tbody>
            HTML;
            while($a < $nbx){
                echo"<tr>";
                td($listeUsers[$a]["equipe"],0);
                td($listeUsers[$a]["total"],0);
                echo"</tr>";
                $a += 1;
            }
            echo <<<HTML
                    </tbody>
                </table>
            HTML;
        }

        // Afficher le resultats par equipes//
        function tabResult(){
            include("connexion_BDD.php");
            $q = $pdo->prepare('SELECT * FROM score');
            $q->execute();
            $f = $pdo->prepare('SELECT COUNT(*) FROM score');
            $f->execute();
            $listeUsers = $q->fetchAll(PDO::FETCH_ASSOC);
            $nbUsers = $f->fetchAll(PDO::FETCH_COLUMN);
            $a = 0;
            $nbx = $nbUsers[0];
            while($a < $nbx){
                $name = $listeUsers[$a]["equipe"];
                echo <<<HTML
                    <table>
                        <thead>
                            <tr>
                                <th style ="border:2px solid; text-align:center"colspan ="26">$name</th>
                            </tr>
                        </thead>
                        <tr>
                            <th style ="border:1px solid; width:80px;">Semaines</th>
                HTML;
                $num = 1;
                while($num != 26){
                    echo <<<HTML
                            <th style ="border:1px solid; width:30px;">$num</th>
                    HTML;
                    $num += 1;
                }
                $num = 1;
                echo <<<HTML
                    </tr>   
                    <tr>    
                        <th style ="border:1px solid; width:80px;">Aller</th> 
                HTML;
                while($num != 26){
                    $aller = "aller_$num";
                    $point = $listeUsers[$a]["$aller"];
                    echo <<<HTML
                        <td style ="border:1px solid; width:30px;">$point</td>
                    HTML;
                    $num += 1;
                }
                $num = 1;
                echo <<<HTML
                    </tr>   
                    <tr>    
                        <th style ="border:1px solid; width:80px;">Retour</th> 
                HTML;
                while($num != 26){
                    $retour = "retour_$num";
                    $point = $listeUsers[$a]["$retour"];
                    echo <<<HTML
                        <td style ="border:1px solid; width:30px;">$point</td>
                    HTML;
                    $num += 1;
                }
                echo <<<HTML
                        </tr>
                    </table>
                HTML;
                if($_SESSION["connecte"]===1 || $_SESSION["connecte"]===2){
                    $equipeId = $listeUsers[$a]["id"];
                    echo <<<HTML
                        <form action="modif.php" style ="margin-bottom:1px"method="post">
                            <input hidden  type="text" name="Modifier" value=$equipeId >
                            <button type="submit" class="btn btn-outline-success" style>Ajouter ou Modifier les resultats</button>
                        </form>
                        </br>
                    HTML;
                }
                $a += 1;
                echo <<<HTML
                    </br>
                    </br>
                HTML;
            }
        }

        // Modifie le total des points//
        function addTotal($x){
            $y = 0;
            $id = $_POST["modifiertotal"];
            while ($y != $x){
                $y += 1;
                $aller = "aller_$y";
                $retour = "retour_$y";
                if(isset($_POST[$aller])){
                    include("connexion_BDD.php");
                    $s = 'UPDATE score SET $aller = $_POST[$aller] WHERE id =(:id)';
                    $q = $pdo->prepare($s);
                    $q->execute([
                        'id' => $id
                    ]);
                }
                if(isset($_POST[$retour])){
                    include("connexion_BDD.php");
                    $s = 'UPDATE score SET $retour = $_POST[$retour] WHERE id =(:id)';
                    $q = $pdo->prepare($s);
                    $q->execute([
                        'id' => $id
                    ]);
                }
            }
            $somme = 0;
            $y = 0;
            while($y != $x){
                $somme += $_POST[$aller];
                $somme += $_POST[$retour];
                $y += 1;
            }
            include("connexion_BDD.php");
            $s = 'UPDATE score SET total = $somme WHERE id =(:id)';
            $q = $pdo->prepare($s);
            $q->execute([
                'id' => $id
            ]);
        }

    // Fin Function Authentification //

?>