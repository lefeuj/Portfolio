<?php

    // Chargement Des Pages //

    include_once "header.php";
    include_once "functions.php";

    // Fin Chargement Des Pages //

    $id = $_POST["Modifier"]
?>
</br>
</br>
</br>
</br>

<!-- Section Modification Des Resultats -->

<form action="resultat.php" style ="margin-bottom:1px"method="post">
    <table>
        <thead>
            <tr>
                <th style ="border:2px solid; text-align:center"colspan ="10">Resultat</th>
            </tr>
            <tr>
                <th style ="border:1px solid; width:80px;">Semaines</th>
                <?= tabModif(25,null) ?>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th style ="border:1px solid; width:80px;">aller</th>
                <?= tabModif(25,"tab-aller") ?>
            </tr>
            <tr>
                <th style ="border:1px solid; width:80px;">retour</th>
                <?= tabModif(25,"tab-retour") ?>
            </tr>
        </tbody>
    </table>
    <input hidden  type="text" name="modifiertotal" value=$id >
    <button type="submit" class="btn btn-outline-success" style>Valider</button>
</form>

<!-- Fin Section Modification Des Resultats -->
