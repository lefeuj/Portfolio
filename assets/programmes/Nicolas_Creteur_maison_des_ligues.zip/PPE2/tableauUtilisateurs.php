<?php

    // Chargement Des Pages //

    include_once "functions.php";

    // Fin Chargement Des Pages //

    validateDeleteUser($pdo);

    $q = $pdo->prepare('SELECT * FROM users');
    $q->execute();
    $f = $pdo->prepare('SELECT COUNT(*) FROM users');
    $f->execute();
    $listeUsers = $q->fetchAll(PDO::FETCH_ASSOC);
    $nbUsers = $f->fetchAll(PDO::FETCH_COLUMN);
    $dt = ['nbUsers'=>$nbUsers];
    $data = ['listUsers'=>$listeUsers];
    $userx = $listeUsers[3]["nom"];
?>

<!-- Section Body Reservé à l'Admin -->
      
Bonjour Admin
<br>
<br>
Voici la liste des utilisateurs dont vous pouvez en valider ou en refuser l'adhésion 
<br>
<br>
<table>
    <?=th("nom","prénom","email")?>
    <?=tableauUsers($nbUsers,$listeUsers,"Accepter")?>
</table>
<br>
Voici la liste des utilisateur ayant été valider.
<br>
Vous pouvez suspendre l'utilisateur, le ré-activer ou le supprimer.
<br>
Attention ! la suppression d'un utilisateur
<br>
est definitive, il est impossible d'annuler la suppression"
<br>
<br>
<table>
    <?=th("nom","prénom","email")?>
    <?=tableauUsers($nbUsers,$listeUsers,"Supprimer")?>
</table>

<!-- Section Body Reservé à l'Admin -->
<br>
<br>