<?php 

  // Chargement Des Pages //

  include "header.php";

  // Fin Chargement Des Pages //
?>

<!-- Section Body Article -->

<body>  

  <div class="container">
    <h1>Articles</h1>
  </div>

  <!-- Container Article -->

  <table>

    <thead>
      <tr>
        <th style ="border:1px solid">Titre</th>
      </tr>
    </thead>
      
    <tbody>

      <tr>
        <td style ="border:1px solid">20/18/2029</td>
      </tr>

      <tr>
        <td style ="border:1px solid">Article</td>
      </tr>

      <tr>
        <td style ="border:1px solid">Michel Joubert</td>
      </tr>

     </tbody>

  </table>

  <!-- Fin Container Article -->

</body> 

<!-- Fin Section Body Article -->

<!-- Section Footer -->

<?php include_once "footer.php" ?>

<!-- Fin Section Footer -->
