<?php 

  // Chargement Des Pages //

  include_once "header.php";

  // Fin Chargement Des Pages //
?>

<!-- Section Body Index -->

<body>
  <style>
    body {
      background-image:url(public/images/nba.jpg);
      background-repeat:no-repeat;
      background-attachment:fixed;
      background-size:100%;
    }
  </style>

  <div class="container">
    <h1 style="color:whitesmoke"><strong>La Maison Des Ligues</strong></h1>
  </div>

</body>

<!-- Fin Section Body Index -->

<!-- Section Footer -->

<?php include_once "footer.php" ?>

<!-- Fin Section Footer -->

