<?php 

  // Chargement Des Pages //

  include_once "header.php";

  // Fin Chargement Des Pages //
  
?>

<!-- Section Body Presentation Des Equipes -->

<body>

  <div class="container">
    <h1>Presentation des équipes</h1>
  </div>

  <!-- Section Tableau Presentation Des Equipes -->

  <?php
    include_once "connexion_BDD.php";
    $q = $pdo->prepare('SELECT * FROM images');
    $q->execute();
    $f = $pdo->prepare('SELECT COUNT(*) FROM images');
    $f->execute();
    $listeUsers = $q->fetchAll(PDO::FETCH_ASSOC);
    $nbUsers = $f->fetchAll(PDO::FETCH_COLUMN);
    $dt = ['nbUsers'=>$nbUsers];
    $data = ['listUsers'=>$listeUsers];
    $userx = $listeUsers[3]["nom"];
  ?>

  <table>

    <thead>
      <tr>
        <th style="border: 1px solid; border-color:black;">Logo</th>
        <th style="border: 1px solid; border-color:black;">Equipe</th>
        <th style="border: 1px solid; border-color:black;">Entraineur</th>
        <th style="border: 1px solid; border-color:black;">Infos</th>
      </tr>
    </thead>

    <tbody>
      <?=tableauEquipe($nbUsers,$listeUsers)?>
    </tbody>

  </table>

  <!-- Fin Section Tableau Presentation Des Equipes -->

</body>

<!-- Fin Section Body Presentation Des Equipes -->

<!-- Section Footer -->

<?php include_once "footer.php" ?>

<!-- Fin Section Footer -->