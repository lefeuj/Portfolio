<?php

    // Si clique sur logout on reinitialise tous et on transfere vers l'accueil //

    session_destroy();
    session_start();
    unset($_SESSION['connecte']);
    header('location: /index.php')

?>