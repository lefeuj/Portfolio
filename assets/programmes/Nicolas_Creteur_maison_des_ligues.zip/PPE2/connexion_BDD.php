<?php 

  // Connection à La BDD //

  $host = 'mysql:host=localhost';
  $dbName = 'dbname=ppe2_nicolas';
  $login = 'nicolas';
  $password = '3skXwPKjd';
  try{
    $pdo = new PDO("$host;$dbName",$login,$password);
  }
  catch(PDOException $e){
    echo 'connexion echouée : '.$e->getMessage();
    echo "<br>";
  }

  // Fin Connection à La BDD //
?>
