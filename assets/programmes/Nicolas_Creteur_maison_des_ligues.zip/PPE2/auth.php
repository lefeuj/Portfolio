<?php

    // Function Authentification //

        // Si un user est connecter alors session-start //
        function userConnecter(): bool {
            if(session_status() === PHP_SESSION_NONE){
                session_start();
            }
            return !empty($_SESSION['connecte']);
        }

        // Si un user est déconnecter alors on kill la session et on redirige vers la page d'accueil //
        function userDeconnecter(): void {
            if(!userConnecter()){
                session_start();
                session_destroy();
                header("location: /index.php");
                exit();
            }
        }

        // Si un user est connecter alors boutton logout sinon login //
        function btnLoginLogout(){
            if(userConnecter() == true){
                return btnNavigation("logout");
            }
            if(userConnecter() == false){
                return btnNavigation("login");
            }
        }

        // Si le users connecter est Admin alors menu secret dashboard //
        function btnNavigationPrivée(){
            if((userConnecter() == true) && ($_SESSION['connecte'] == 2)){
                return btnNavigation("dashboard");
            }
        }

        // function raccourci location //
        function redirection($x){
            if(userConnecter()){
                return header("location: /$x.php");
            }
        }

    // Fin Function Authentification //

?>