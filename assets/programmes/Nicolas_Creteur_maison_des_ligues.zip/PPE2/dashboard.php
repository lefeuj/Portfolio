<?php 

  // Chargement Des Pages //

  include_once "header.php";
  include_once "connexion_BDD.php";

  // Fin Chargement Des Pages //

  // Si user est connecter alors session start + connection en temps que Admin ou autre //
  userDeconnecter();
  if($_SESSION['connecte'] != 2){
    redirection("index");
  }

?>

<!-- Section Body Article -->

<body>
  <div class="container">
    <h1 >Dashboard</h1>
  </div> 

  <!-- Section Tableau Users -->

  <?php 
    include_once "tableauUtilisateurs.php";
  ?>

  <!-- Fin Section Tableau Users -->

</body>

<!-- Fin Section Body Article -->

<!-- Section Footer -->

<?php 
  include_once "footer.php"
?>

<!-- Fin Section Footer -->