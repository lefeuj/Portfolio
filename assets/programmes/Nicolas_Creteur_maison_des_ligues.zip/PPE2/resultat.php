<?php 

  // Chargement Des Pages //

  include_once "header.php";

  // Fin Chargement Des Pages //

?>

<!-- Section Body Affichage des resultats -->

<body>

  <?php include_once "tabResult.php"; ?>

</body>

<!-- Fin Section Body Affichage des resultats -->

<!-- Section Footer -->

<?php include_once "footer.php" ?>

<!-- Fin Section Footer -->