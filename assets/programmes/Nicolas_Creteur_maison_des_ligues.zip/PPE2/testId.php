<?php

    // Chargement Des Pages //

    include_once "functions.php";
    include_once "connexion_BDD.php";

    // Fin Chargement Des Pages //

    // test Login et MDP //

        // test que les champs login et mdp sont bien remplis // 
        if(isset($_POST["Login"]) || isset($_POST["password"])){
            if(!empty($_POST["Login"]) && !empty($_POST["password"])){
                $login = $_POST["Login"];
                $password = $_POST["password"];
                $req = $pdo->prepare('SELECT * FROM users WHERE login=(:login)');
                $req->execute([
                'login' => $login
                ]);
                $pass = $req->fetchAll(PDO::FETCH_ASSOC);
                $tabmdp = ['pass'=>$pass];
                $b = $pass[0];

                // test que login et mdp soient exact //
                if(($login === $b["login"]) && ($password === $b["password"])){

                    // verifie si le compte user est Admin ou User, et si le compte est actif, en pause, ou en attente de validation //
                    if($b["valider"] !== "0"){
                        if($b["pause"] !== "1"){
                            if($b["admin"] === "1"){
                                session_start();
                                $_SESSION['connecte'] = 2;
                                redirection("dashboard");
                                exit();
                            }
                            else{
                                session_start();
                                $_SESSION['connecte'] = 1;
                                redirection("index");
                                exit();
                            }
                        }

                        // Messages erreurs //
                        else{
                        $erreur = 2;
                        }
                    }
                    else{
                        $erreur = 3;
                    }
                }
                else{
                    $erreur = 1;
                }
            }
            else{
                $erreur = 4;
            }
            // Fin messages erreurs //
        }

    // Fin test Login et MDP //
?>
