<?php

  // Chargement Des Pages //

  include_once "functions.php";

  // Fin Chargement Des Pages //

  addTotal(25)

?>

<!-- Section Body Affichage des resultats -->

</br> 

<div class ="row" style="height:80%;">
    <div class ="col-4"style="width:5%">
    </div>
      <div class ="col-4" style="width:40%">
        <h4>Total des points</h4>
        </br>
        <?= tabTotal() ?>
      </div>
      <div class ="col-4"style="width:45%">
        <h4>Détail des points</h4>
        </br>
            <?= tabResult() ?>
      </div>
    </div>

<!-- Fin Section Body Affichage des resultats -->
