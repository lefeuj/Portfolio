﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinAppTicket.Models
{
    public class Ticket
    {
        public static readonly Ticket Empty;

        public Guid Uid { get; set; } = Guid.Empty;
        public bool Enabled { get; set; } = false;
        public short State { get; set; } = 0;
        public Guid UidCustomer { get; set; } = Guid.Empty;
        public string Customer { get; set; } = string.Empty;
        public string Object { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}
