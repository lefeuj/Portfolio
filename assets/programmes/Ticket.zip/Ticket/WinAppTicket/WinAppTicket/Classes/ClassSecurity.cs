﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinAppTicket.Models;

namespace WinAppTicket.Classes
{
    public class Security
    {
        public static string SqlConnectionString = "Data Source=127.0.0.1;Initial Catalog=dbAppTicket;Integrated Security=True";
        public static User CurrentUser { get; set; } = User.Empty;
    }
}
