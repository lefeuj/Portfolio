﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinAppTicket.Classes
{
    public class Param
    {
        public static string AppName = "AppTicket";
    }
}
