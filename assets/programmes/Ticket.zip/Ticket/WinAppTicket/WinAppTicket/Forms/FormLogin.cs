﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinAppTicket.Classes;

namespace WinAppTicket.Forms
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }
        private void BtnValidate_Click(object sender, EventArgs e)
        {
            
            try
            {
                
                SqlConnection sqlConnection = new SqlConnection(Security.SqlConnectionString);
                sqlConnection.Open();
                try
                {
                    string crypto = Classes.StringCipher.Encrypt(this.txtPassword.Text);
                    string sQuery = "SELECT * FROM tbUser WHERE Login=@Login";
                    SqlCommand sqlCommand = new SqlCommand(sQuery, sqlConnection);
                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                    if(crypto == sQuery)
                    {
                        while (sqlDataReader.Read())
                        {
                            if ((bool)sqlDataReader["Enabled"] && (string)sqlDataReader["Password"] == this.txtPassword.Text)
                            {
                                Security.CurrentUser = new Models.User()
                                {
                                    Uid = (Guid)sqlDataReader["Uid"],
                                    Enabled = (bool)sqlDataReader["Enabled"],
                                    NameLast = (string)sqlDataReader["NameLast"],
                                    NameFirst = (string)sqlDataReader["NameFirst"],
                                    Login = (string)sqlDataReader["Login"],
                                    Password = (string)sqlDataReader["Password"],
                                    Email = (string)sqlDataReader["Email"]
                                };
                            }
                            else { MessageBox.Show(Param.AppName, "Nom d'utilisateur et/ou mot de passe incorrect.", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                        }
                    }
                    crypto = Classes.StringCipher.Decrypt(this.txtPassword.Text);

                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
                sqlConnection.Close();
            }
            
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }
    }
}
