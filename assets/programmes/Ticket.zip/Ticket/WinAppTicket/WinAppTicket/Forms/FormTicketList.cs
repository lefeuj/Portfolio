﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinAppTicket.Classes;
using WinAppTicket.Models;

namespace WinAppTicket.Forms
{
    public partial class FormTicketList : Form
    {
        public FormTicketList()
        {
            InitializeComponent();
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlConnection = new SqlConnection(Security.SqlConnectionString);
                sqlConnection.Open();
                try
                {
                    string sQuery = "SELECT * FROM tbTicket";
                    SqlCommand sqlCommand = new SqlCommand(sQuery, sqlConnection);
                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                    List<Ticket> tickets = new List<Ticket>();
                    while (sqlDataReader.Read())
                    {
                        Ticket ticket = new Ticket()
                        {
                            Uid = (Guid)sqlDataReader["Uid"],
                            Enabled = (bool)sqlDataReader["Enabled"],
                            State = (short)sqlDataReader["State"],
                            UidCustomer = (Guid)sqlDataReader["UidCustomer"],
                            Customer = (string)sqlDataReader["Customer"],
                            Object = (string)sqlDataReader["Object"],
                            Description = (string)sqlDataReader["Description"]
                        };
                        tickets.Add(ticket);
                    }
                    this.dataGridView1.DataSource = tickets;
                    this.dataGridView1.Refresh();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }
    }
}
