﻿
namespace WinAppTicket.Forms
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiQuit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTicket = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiTicketList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiTicketCreate = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuTicket});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiQuit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(54, 20);
            this.mnuFile.Text = "&Fichier";
            // 
            // tsmiQuit
            // 
            this.tsmiQuit.Name = "tsmiQuit";
            this.tsmiQuit.Size = new System.Drawing.Size(180, 22);
            this.tsmiQuit.Text = "&Quitter";
            this.tsmiQuit.Click += new System.EventHandler(this.TsmiQuit_Click);
            // 
            // mnuTicket
            // 
            this.mnuTicket.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiTicketList,
            this.tsmiTicketCreate});
            this.mnuTicket.Name = "mnuTicket";
            this.mnuTicket.Size = new System.Drawing.Size(51, 20);
            this.mnuTicket.Text = "&Ticket";
            // 
            // tsmiTicketList
            // 
            this.tsmiTicketList.Name = "tsmiTicketList";
            this.tsmiTicketList.Size = new System.Drawing.Size(180, 22);
            this.tsmiTicketList.Text = "&Liste des tickets";
            this.tsmiTicketList.Click += new System.EventHandler(this.TsmiTicketList_Click);
            // 
            // tsmiTicketCreate
            // 
            this.tsmiTicketCreate.Name = "tsmiTicketCreate";
            this.tsmiTicketCreate.Size = new System.Drawing.Size(180, 22);
            this.tsmiTicketCreate.Text = "&Créer un ticket";
            this.tsmiTicketCreate.Click += new System.EventHandler(this.TsmiTicketCreate_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem tsmiQuit;
        private System.Windows.Forms.ToolStripMenuItem mnuTicket;
        private System.Windows.Forms.ToolStripMenuItem tsmiTicketList;
        private System.Windows.Forms.ToolStripMenuItem tsmiTicketCreate;
    }
}