﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinAppTicket.Classes;
using WinAppTicket.Models;

namespace WinAppTicket.Forms
{
    public partial class FormTicketCreate : Form
    {
        public FormTicketCreate()
        {
            InitializeComponent();
        }
        private void FormTicketCreate_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlConnection = new SqlConnection(Security.SqlConnectionString);
                sqlConnection.Open();
                try
                {
                    string sQuery = "SELECT * FROM tbCustomer";
                    SqlCommand sqlCommand = new SqlCommand(sQuery, sqlConnection);
                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                    List<Customer> customers = new List<Customer>();
                    while (sqlDataReader.Read())
                    {
                        Customer ticket = new Customer()
                        {
                            Uid = (Guid)sqlDataReader["Uid"],
                            Name = (string)sqlDataReader["Name"]
                        };
                        customers.Add(ticket);
                    }
                    this.cboCustomer.DataSource = customers;
                    this.cboCustomer.DisplayMember = "Name";
                    this.cboCustomer.ValueMember = "Uid";
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private void BtnValidate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlConnection = new SqlConnection(Security.SqlConnectionString);
                sqlConnection.Open();
                try
                {
                    string sQuery = "INSERT INTO tbTicket (Uid, State, UidCustomer, Customer, Object, Description) VALUES (@Uid, @State, @UidCustomer, @Customer, @Object, @Description)";
                    SqlCommand sqlCommand = new SqlCommand(sQuery, sqlConnection);

                    Customer customer = (Customer)this.cboCustomer.SelectedItem;

                    sqlCommand.Parameters.Add(new SqlParameter("@Uid", Guid.NewGuid()));
                    sqlCommand.Parameters.Add(new SqlParameter("@State", 0));
                    sqlCommand.Parameters.Add(new SqlParameter("@UidCustomer", customer.Uid));
                    sqlCommand.Parameters.Add(new SqlParameter("@Customer", customer.Name));
                    sqlCommand.Parameters.Add(new SqlParameter("@Object", this.txtObject.Text));
                    sqlCommand.Parameters.Add(new SqlParameter("@Description", this.rtbDescription.Text));
                    int iRes = sqlCommand.ExecuteNonQuery();
                    if (iRes > 0) { this.Close(); }
                    else { MessageBox.Show("Enregistrement Impossible", "Ticket", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e) { this.Close(); }

    }
}
