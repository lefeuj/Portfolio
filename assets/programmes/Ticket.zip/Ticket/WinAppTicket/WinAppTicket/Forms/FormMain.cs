﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinAppTicket.Forms
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void TsmiQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //--------------------------------------------------//

        private void TsmiTicketList_Click(object sender, EventArgs e)
        {
            FormTicketList form = new FormTicketList
            {
                MdiParent = this
            };
            form.Show();
        }
        private void TsmiTicketCreate_Click(object sender, EventArgs e)
        {
            FormTicketCreate form = new FormTicketCreate
            {
                MdiParent = this
            };
            form.Show();
        }
    }
}
