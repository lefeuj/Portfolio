﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinAppTicket
{
    static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Forms.FormLogin formLogin = new Forms.FormLogin();
            if (formLogin.ShowDialog() == DialogResult.OK) { Application.Run(new Forms.FormMain()); }

            //Application.Run(new Forms.Form1());
        }
    }
}
