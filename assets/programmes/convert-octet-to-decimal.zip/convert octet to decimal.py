#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      niko
#
# Created:     10/02/2021
# Copyright:   (c) niko 2021
# Licence:     <your licence>
#----------------------------------------------------------------------------
valeurip = input ("merci de saisir une adresse IP comprenant 4 octets en binaire sans séparations:")
result = []
I = (128)
for n in range(0,len(valeurip)):
    index=int(n/8)
    if n%8==0:
        I=128
        result.append(0)
    if n < len(valeurip):
        val = int(valeurip[n])*I
        result[index] = int(val + result[index])
        I = I/2
decimal = ".".join(map(str,result))
print("En décimal , votre adresse IP est : " + decimal)