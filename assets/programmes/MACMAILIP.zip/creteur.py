import re

def testMail(x):
    #la fonction testMail est un booleen
    x = x + "!"
    # on ajoute un "!" à la fin de l'adresse mail afin de ne pas faire d'erreur 
    # par exemple si au millieu du mail il y a un .fr
    # nicolas.FRançois....
    Dommaine = [".fr!",".com!",".eu!",".net!",".org!"]
    # je ne vais pas mettre les 900 noms de dommaine, j'ai mis les plus connus pour l'exemple
    # et je suis sur qu'il y a déjà une librairie qui contient les 900 noms de dommaine mais fleme de chercher
    dommaineTrouver = False
    arobaseTrouver = False
    espaceTrouver = True
    emailValide = False
    for i in Dommaine:
        if(re.search(i,x)):
            dommaineTrouver = True;
    if(len(re.findall("@",x)) == 1):
        # on verifie qu'il n'y a qu'un seul arobase
        arobaseTrouver = True;
    if(re.search(" ",x)):
        # on verifie qu'il n'y a pas d'espace dans l'Email
        espaceTrouver = False;
    if((dommaineTrouver) & (arobaseTrouver) & (espaceTrouver)):
        # on verifie que toutes les conditions sont remplis
        emailValide = True
    # pas besoin de chercher si la case est en minuscule ou majuscule
    # puisque les serveur d'adresse mail ignore la case
    # on aurai pu tester aussi si l'adresse Email :
    #                                        - ne contient pas d'accent, ni de cédille, ni de caractères accentués.
    #                                        - ne débute pas par un chiffre ou uniquement constituée de chiffres (de type 1234@orange.fr).
    #                                        - ne contient que les lettres (de A à Z), et les chiffres (de 0 à 9), 
    #                                             les tirets (-) et les points (.) entre les lettres (mais sans finir par un point).
    return emailValide

def testMAC(x):
    MACValide = False
    MAC = True
    x = x.upper()
    # on met l'adresse MAC en majuscule afin d'anuler d'enventuels fautre de frappe utilisateur
    Hexadecimal = "0123456789ABCDEF:"
    # on initie la variable avec toutes les valeurs possible que peut contenir une adresse MAC
    indice1 = 0
    x2 = x.split(":")
    while(indice1 != len(x)):
        # ici on va comparer chaques caracteres de l'adresse MAC avec la variable
        # si different alors !MAC
        if(re.search(x[indice1],Hexadecimal)):
            indice1 += 1;
        else:
            return MACValide
    if(len(x2) == 6):
        # on verifie que l'adresse est bien constituer de 6 octets
        indice2 = 0
        while(indice2 != 6):
            if(len(x2[indice2]) == 2):
                indice2 += 1;
            else:
                return MACValide
    if(len(x2) != 6):
        return MACValide
    if(len(re.findall(":",x)) != 5):
        # on verifie que le nombres de separateurs ":" est egal à 5
        return MACValide
    if((x[0] == ":") | (x[-1] == ":")):
        # on verifie que l'adresse MAC ne commence ni ne termine par ":"
        return MACValide
    # il y a très certainement d'autres conditions auxquels je n'ai pas penser
    if(MAC):
        MACValide = True
    return MACValide

def testIPV4(x):
    IPV4Valide = "G"
    ip = True
    classe = None
    nb = "0123456789."
    indice = 0
    x2 = x.split(".")
    while(indice != len(x)):
        # ici on va comparer chaques caracteres de l'IPV4 avec la variable
        # si different alors !IPV4
        if(re.search(x[indice],nb)):
            indice += 1;
        else:
            return IPV4Valide
    if((x[0] == ".") | (x[-1] == ".")):
        # on verifie que l'adresse IPV4 ne commence ni ne termine par "."
        return IPV4Valide
    x3 = int(x2[0])
    if(len(x2) == 4):
        # on verifie qu'il y ai bien 4 octets
        indice2 = 0
        while indice2 < 4 :
            # on verifie qu'il n'y ai pas une valeur à null
            if(x2[indice2] == ""):
                return IPV4Valide
            else:
                indice2 += 1
        for i in x2:
            # on verifie que tous les octets on une valeur comprise entre 0 et 255
            if((int(i) < 0) | (int(i) > 255)):
                return IPV4Valide
        if((x3 >= 0) & (x3 <= 126)):
            # et enfin on determine de quel type de classe il s'agit 
                classe = "A"
                ip = True
        if(x3 == 127):
                classe = "F"
                ip = True;
        if((x3 >= 128) & (x3 <= 191)):
                classe = "B"
                ip = True
        if((x3 >= 192) & (x3 <= 223)):
                classe = "C"
                ip = True
        if((x3 >= 224) & (x3 <= 239)):
                classe = "D"
                ip = True
        if((x3 >= 240) & (x3 <= 255)):
                classe = "E"
                ip = True
    if(len(x2) != 4):
        return IPV4Valide
    if(ip):
        IPV4Valide = classe
    return IPV4Valide

def test(x):
    y = None
    if(testMail(x)):
        y = "la chaine de caractere saisis correspond à une adresse Email valide "
        print("|          " + y + "                                                       |")
        print("|                                                                                                                                     |")
        print("|_____________________________________________________________________________________________________________________________________|")
        exit()
    elif(testMAC(x)):
        y = "la chaine de caractere saisis correspond à une adresse MAC valide "
        print("|          " + y + "                                                         |")
        print("|                                                                                                                                     |")
        print("|_____________________________________________________________________________________________________________________________________|")
        exit()
    elif(testIPV4(x) != "G"):
        if(testIPV4(x) == "A"):
            y = "il s'agit d'une adresse IPV4 de classe A"
        if(testIPV4(x) == "F"):
            y = "Cette adresse IPV4 (127.0.0.0) est réservée pour les communications en boucle locale."
        if(testIPV4(x) == "B"):
            y = "il s'agit d'une adresse IPV4 de classe B"
        if(testIPV4(x) == "C"):
            y = "il s'agit d'une adresse IPV4 de classe C"
        if(testIPV4(x) == "D"):
            y = "il s'agit d'une adresse IPV4 de classe D, il s'agit d'une zone d'adresses dédiées aux services de multidiffusion vers des groupes d'hôtes (host groups)."
        if(testIPV4(x) == "E"):
            y = "il s'agit d'une adresse IPV4 de classe E, il s'agit d'une zone d'adresses réservées aux expérimentations. Ces adresses ne doivent pas être utilisées pour adresser des hôtes ou des groupes d'hôtes."
        print("|          " + y + "                                                                                   |")
        print("|                                                                                                                                     |")
        print("|_____________________________________________________________________________________________________________________________________|")
        exit()
    else:
        y = "la chaine de caractere saisis ne correspond ni à une adresse Email, ni à une adresse MAC, ni à une adresse IPV4 "
        print("|          " + y + "           |")
        print("|                                                                                                                                     |")
        print("|_____________________________________________________________________________________________________________________________________|")
        exit()
print("._____________________________________________________________________________________________________________________________________.")
print("|                                                                                                                                     |")
print("|                                                                                                                                     |")
valeur = input("|         veuillez saisir une adresse Email, MAC ou IPV4 afin de la tester => ")
print("|                                                                                                                                     |")
print("|                                                                                                                                     |")

test(valeur)