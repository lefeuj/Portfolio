<?php
if(isset($_POST['connection'])){
    if (isset($_POST['login']) AND !empty($_POST['login']) AND isset($_POST['password']) AND !empty($_POST['password'])) {
        try{
            $bdd = new PDO('mysql:host=localhost;dbname=m2l', 'root', '');
        }
        catch(Exception $e)
        {
            die('Erreur : '.$e->getMessage());
        }

        $req = $bdd->prepare('SELECT Login,Password FROM adhérants WHERE login=:Login AND password=:Password ');
        $req->execute(array(':Login'=>$_POST['login'],':Password'=>$_POST['password']));
        $donnees = $req->fetch();
        if(!empty($donnees)){
            include_once('connecter.php');
        }
        else{
            $x= "Votre login ou mot de passe est incorrect";
            include_once('pageco.php?error='.$x);
        }
    }
    else{
        echo "Votre login ou mot de passe est incorrect";
    }
}
?>