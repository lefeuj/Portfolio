<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
    <?php
        include_once("./pageVierge/head.php");
    ?>
    <body>
        <div class="logo">
            <img src="/images/fond.jpg" alt="imgaccueil" width=100% />
            <div class=losange1>
                <div class=losange2>
                    <form action="coBdd.php" method="post">
                        <input class=log type="text" name="login" placeholder="Login">
                        </input>
                        <input class=log type="password" name="password" placeholder=" Password">
                        </input>
                        </br>
                        <?php
                        include_once("./coBdd.php");
                        ?>
                        <button type="submit" name="connection"
                        class="btn btn-outline-primary" href>CONNECTION
                        </button>
                        <a class=btnco href="createUser.php">
                            s'inscrire
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </body>
    <?php
        include_once("./pageVierge/footer.php");
    ?>
</html>