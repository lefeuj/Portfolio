<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">

    <?php
        include_once("./pageVierge/head.php");
    ?>
    <main>
        <div class = forminscription>
            <div class="forminscription2" id="inscription">
                <label for="exampleFormControlInput1" class="form-label">Date</label>
                <input type="date" name="date" class="form-control" id="exampleFormControlInput1" placeholder="la date">
                <label for="exampleFormControlInput1" class="form-label">Trajet</label>
                <input type="texte" name="trajet" class="form-control" id="exampleFormControlInput1" placeholder="le trajet">
                <label for="exampleFormControlInput1" class="form-label">Kilometrage</label>
                <input type="texte" name="km" class="form-control" id="exampleFormControlInput1" placeholder="km">
                <label for="exampleFormControlInput1" class="form-label">Couit-Peage</label>
                <input type="texte" name="cout-peage" class="form-control" id="exampleFormControlInput1" placeholder=" total peage">
                <label for="exampleFormControlInput1" class="form-label">Cout-Repas</label>
                <input type="texte" name="cout-repas" class="form-control" id="exampleFormControlInput1" placeholder="total repas">
                <label for="exampleFormControlInput1" class="form-label">Cout-Hebergement</label>
                <input type="texte" name="cout-hebergement" class="form-control" id="exampleFormControlInput1" placeholder="total hebergement">
                <label for="exampleFormControlInput1" class="form-label">Motif</label>
                <input type="commmentaire" name="motif" class="form-control" id="exampleFormControlInput1" placeholder="le motif">
                <button type="submit" name="valider" class="btn btn-primary">Valider</button>
            </div>
        </div>
    </main>
    <?php
        include_once("./pageVierge/footer.php");
    ?>
</html>