<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
    <?php
        include_once("./pageVierge/head.php");
    ?>
    <body>
        <div class="forminscription">
            <fieldset class="forminscription2" from="inscription">
                <input type="texte" name="nom utilisateur" class="form-control" id="exampleFormControlInput1" require="require" placeholder="nom utilisateur"></br>
                <input type="texte" name="mot de passe" class="form-control" id="exampleFormControlInput1" require="require" placeholder="mot de passe"></br>
                <input type="texte" name="confirmer le mot de passe" class="form-control" id="exampleFormControlInput1" require="require" placeholder="confirmer le mot de passe"></br>
                <a href="connecter.php"><button type="submit" name="valider" class="btn btn-primary">Valider</button></a>
            </fieldset>
        </div>
    </body>
    <?php
        include_once("./pageVierge/footer.php");
    ?>
</html>