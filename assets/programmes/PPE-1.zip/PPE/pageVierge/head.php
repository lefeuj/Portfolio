<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <div class="entete">
        <meta charset="utf-8" />
        <link rel="stylesheet" href="bootstrap/bootstrap-grid.css" />
        <link rel="stylesheet" href="bootstrap/bootstrap-reboot.css" />
        <link rel="stylesheet" href="bootstrap/bootstrap.css" />
        <link rel="stylesheet" href="css/StyleSheet.css" />
        <title>Porte Folio Créteur Nicolas</title>
        <div class="info1">
            Créteur Nicolas
        </div>
        <div class="info2">
            PPE
        </div>
        <div class="info3">
            2020/2022
        </div>
    </div>
</head>
<body>
    <header>
        <nav class="menu-nav">
            <ul>
                <li class="btn">
                    <a href="Acceuil.php">
                        ACCUEIL
                    </a>
                </li>
                <li class="btn">
                    <a href="pageco.php">
                        CONNECTION
                    </a>
                </li>
            </ul>
        </nav>
    </header>