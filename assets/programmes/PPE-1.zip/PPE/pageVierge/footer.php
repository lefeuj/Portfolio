<footer>
    <div class="pied2">
    <div class="ufip">
        <img src="/images/ufip.png" alt="imgaccueil" width=100% />
    </div>
    </div>
    </footer>
</body>

</html>