<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">

    <?php
        include_once("./pageVierge/head.php");
    ?>
    <main>
        <div class="logo">
            <img src="/images/fond.jpg" alt="imgaccueil" width=100% />
            <div class="txtaccueil">BIENVENUE</div>
        </div>
    </main>
    <?php
        include_once("./pageVierge/footer.php");
    ?>
</html>