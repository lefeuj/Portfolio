import random
import keyboard
import time
import sys
def flush_input():
    try:
        import msvcrt
        while msvcrt.kbhit():
            msvcrt.getch()
    except ImportError:
        import sys, termios    #for linux/unix
        termios.tcflush(sys.stdin, termios.TCIOFLUSH)

print("                                 .________________________________________________________________________________.")

print("                                 |                                                                                |")
print("                                 |                          BIENVENUE DANS LE JUSTE PRIX                          |")
print("                                 |                                                                                |")
print("                                 |                                                                                |")
print("                                 |                                                                                |")
print("                                 |         - Le but du jeu est de deviner le nombre situé entre 1 et 100          |")
print("                                 |         - Attention ,vous n'avez que 10 essaie !                               |")
print("                                 |                                                                                |")
print("                                 |                                                                                |")
print("                                 |                                   BON JEU :)                                   |")
print("                                 |                                                                                |")
print("                                 |                                                                                |")
print("                                 |                                                                                |")
print("                                 |                        APPUYER SUR ENTREE POUR COMMENCER                       |")
print("                                 |                                       OU                                       |")
print("                                 |                              SUR ECHAP POUR QUITTER                            |")
print("                                 |                                                                                |")
print("                                 !________________________________________________________________________________!")

Jouer = None
Continue = None

while (Jouer == None):
    key = keyboard.read_key()
    if key == "enter":
        Jouer = True
        Continue = True
        break
    if key == "esc":
        Jouer = False
        Continue = False
        break
    
flush_input()

while(Continue == True):
    X = random.randint(1,100)
    Iteration = 0
    Gagner = False
    Perdu = False
    
    print("                                 .________________________________________________________________________________.")
    print("                                 |                                                                                |")

    while((Gagner == False) | (Perdu == False)):
        print("                                 |                             VEUILLEZ SAISIR UN NOMBRE :                        |")
        Z=""
        while(Z==""):
            Z = input()
        print("                                 |                                                                                |")
        while(Z.isnumeric() == False):
            Z = input("                                 |                             VEUILLEZ SAISIR UN NOMBRE :                        |")
            print("                                 |                                                                                |")
        Valeur = int(Z)
        if(Iteration == 0):
            if(Valeur == X):
                print("                                 |                FELICITATION ! VOUS AVEZ TROUVER DU PREMIER COUP                |")
                print("                                 |                                                                                |")
                Gagner = True
            else:
                Iteration += 1
        if((Iteration > 0) & (Iteration <= 10)):
            if(Valeur != X):
                Iteration += 1
            else:
                print("                                 |                  FELICITATION ! VOUS AVEZ TROUVER AU "+ str(Iteration) +"e COUPS                  |")
                print("                                 |                                                                                |")
                Gagner = True
                break
        if(Iteration == 11):
            if(Valeur == X):
                print("                                 |               VOUS AVEZ TROUVER AU DERNIER COUP, BRAVO QUAND MEME              |")
                print("                                 |                                                                                |")
                Gagner = True
                break
            else:
                print("                                 |                                   GAME OVER                                    |")
                print("                                 |                                                                                |")
                Perdu = True
                break
        if(Valeur < X):
            print("                                 |                                        ██                                      |")
            print("                                 |                                        ██                                      |")
            print("                                 |                                   ████████████                                 |")
            print("                                 |                                        ██                                      |")
            print("                                 |                                        ██                                      |")
            print("                                 |                                                                                |")
        if(Valeur > X):
            print("                                 |                                                                                |")
            print("                                 |                                                                                |")
            print("                                 |                                   ████████████                                 |")
            print("                                 |                                                                                |")
            print("                                 |                                                                                |")
            print("                                 |                                                                                |")
    print("                                 !________________________________________________________________________________!")
            
    time.sleep(1)
            
    print("                                 .________________________________________________________________________________.")
    print("                                 |                                                                                |")
    print("                                 |                         APPUYER SUR ENTREE POUR REJOUER                        |")
    print("                                 |                                       OU                                       |")
    print("                                 |                              SUR ECHAP POUR QUITTER                            |")
    print("                                 |                                                                                |")
    print("                                 !________________________________________________________________________________!")
    
    Jouer = None

    while (Jouer == None):
        if keyboard.read_key() == "enter":
            Continue = True
            break
        if keyboard.read_key() == "esc":
            Continue = False
            break
        
#─────────────────────────────
#─────────────▐█▌─────────────
#─────────────▐░▌─────────────
#─────────────▐░▌─────────────
#─────────────▐░▌─────────────
#──────────▄▄▀░░░▀▄▄──────────
#────────▄▀░░░░░░░░░▀▄────────
#──────▄▀░░░░░░░░░░░░░▀▄──────
#─────▐░░░░░░░░░░░░░░░░░▌─────
#────▐░░░░░░░░░░░░░░░░░░░▌────
#───▐░░░░░░░░░░░░░░░░░░░░░▌───
#───▐░░░░░░░░░░░░░░░░░░░░░▌───
#───▐░░░░░░░░░░░░░░░░░░░░░▌───
#───▐▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▌───
#──▄███████████████████████▄──
#─████▀────▀███████▀────▀███▄─
#─███▀───────█████────────███─
#─███───███───███───███───███─
#─███───▀▀▀───███───▀▀▀───███─
#─▀███▄─────▄█████▄─────▄███▀─
#──▀███████████████████████▀──
#───▐░░░░░░░░░░░░░░░░░░░░░▌───
#───▐░░░░░░░░░░░░░░░░░░░░░▌───
#───▐░▄▀▀█▀▀█▀▀█▀▀█▀▀█▀▀▄░▌───
#───▐░█▄▄█▄▄█▄▄█▄▄█▄▄█▄▄█░▌───
#───▐░█──█──█──█──█──█──█░▌───
#───▐░█▀▀█▀▀█▀▀█▀▀█▀▀█▀▀█░▌───
#───▐░▀▄▄█▄▄█▄▄█▄▄█▄▄█▄▄▀░▌───
#───▐░░░░░░░░░░░░░░░░░░░░░▌───
#───▐░░░░░░░░░░░░░░░░░░░░░▌───
#────▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀────