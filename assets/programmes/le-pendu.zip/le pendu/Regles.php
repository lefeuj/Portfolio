<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <div class="entete">
            <meta charset="utf-8" />
            <link rel="stylesheet" href="bootstrap/bootstrap-grid.css" />
            <link rel="stylesheet" href="bootstrap/bootstrap-reboot.css" />
            <link rel="stylesheet" href="bootstrap/bootstrap.css" />
            <link rel="stylesheet" href="css/StyleSheet.css" />
            <title>Le jeu du pendu</title>
            <div class="info1">
                Créteur Nicolas
            </div>
            <div class="info2">
                Jeu Du Pendu
            </div>
            <div class="info3">
                2020/2022
            </div>
        </div>
    </head>
    <body>
        <header>
            <nav class="menu-nav">
                <ul>
                    <li class="btn">
                        <a href="Acceuil.php">
                            Retour
                        </a>
                    </li>
                </ul>
            </nav>
        </header>
        <main>
            <div class="logo2">
                <img src="/images/pendu 0.png" alt="imgaccueil" width=85% />
                <div class="txtbox">
                </div>
                <div class="txtregles">
                        Comment jouer au jeu du Pendu :
                    Dans un premier temps il faut désigner un joueur qui devra deviner le mot. 
                    Pour expliquer plus facilement nous allons partir sur un exemple. 
                    Il y a deux joueurs, Rémi et Margaux.
                    Rémi pense à un mot et Margaux devra le deviner.                         Pour ce faire, Rémi dessine la potence et place en dessous autant de tirets 
                    qu’il y a de lettres dans le mot.
                    Margaux annonce une lettre. La lettre fait-elle partie du mot à deviner ?
                    Si oui, Rémi inscrit la lettre à sa place, sur le tiret correspondant, 
                    et autant de fois que la lettre apparait dans le mot.
                    Si non, Rémi dessine le premier trait du pendu.
                    Le jeu continue jusqu’au moment où l’un des joueurs remporte la partie. 
                    C’est-à-dire :
                    Margaux remporte la partie en découvrant toutes les lettres du mot.
                    Rémi gagne la partie en dessinant tous les trais du pendu.
                    Le nombre de coups dans une partie dépend du nombre de traits qu’il faut pour 
                    réaliser le dessin du pendu.  Il est donc possible d’augmenter le nombre de chance 
                    en dessinant également la potence, et pas seulement le pendu, durant la partie. 
                    Cela facilite le jeu et permet au joueur qui cherche d’avoir plus de chances de 
                    trouver le mot.
                </div>
            </div>
        </main>
        <footer>
            <div class="pied1">
            </div>
            <div class="pied2">
                <div class="ufip">
                </div>
            </div>
        </footer>
    </body>
</html>