<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <div class="entete">
            <meta charset="utf-8" />
            <link rel="stylesheet" href="bootstrap/bootstrap-grid.css" />
            <link rel="stylesheet" href="bootstrap/bootstrap-reboot.css" />
            <link rel="stylesheet" href="bootstrap/bootstrap.css" />
            <link rel="stylesheet" href="css/StyleSheet.css" />
            <title>Le jeu du pendu</title>
            <div class="info1">
                Créteur Nicolas
            </div>
            <div class="info2">
                Jeu Du Pendu
            </div>
            <div class="info3">
                2020/2022
            </div>
        </div>
    </head>
    <body>
        <header>
            <nav class="menu-nav">
                <ul>
                    <li class="btn">
                        <a href="Jouer.php">
                            JOUER
                        </a>
                    </li>
                    <li class="btn">
                        <a href="Regles.php">
                            REGLES
                        </a>
                    </li>
                </ul>
            </nav>
        </header>
        <main>
            <div class="logo">
                <img src="/images/pendu 0.png" alt="imgaccueil" width=100% />
                <div class="txtaccueil">BIENVENUE</div>
            </div>
        </main>
        <footer>
            <div class="pied1">
            </div>
            <div class="pied2">
                <div class="ufip">
                </div>
            </div>
        </footer>
    </body>
</html>