import random 
listeEntiers = [] 
while len(listeEntiers) < 30: 
    x = random.randint(1,200) 
    listeEntiers.append(x) 
print(listeEntiers) 
listeEntiers.append(255) 
listeEntiers.insert(1,255) 
print(listeEntiers) 
for i in listeEntiers:
    if i < 50:  
        listeEntiers.remove(i) 
print(listeEntiers) 
listeEntiers = [y for i, y in enumerate(listeEntiers) if i % 2 == 0] 
print(listeEntiers) 