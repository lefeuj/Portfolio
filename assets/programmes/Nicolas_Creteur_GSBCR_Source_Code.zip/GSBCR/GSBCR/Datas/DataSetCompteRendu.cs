﻿namespace GSBCR.Datas
{


    public partial class DataSetCompteRendu
    {
    }
}
