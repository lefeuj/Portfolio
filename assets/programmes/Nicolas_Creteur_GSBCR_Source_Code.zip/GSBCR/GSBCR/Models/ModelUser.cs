﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSBCR.Models
{
    public class User
    {
        public Guid Uid { get; set; }
        public string Login = null;
        public string Password = null;
    }
}
