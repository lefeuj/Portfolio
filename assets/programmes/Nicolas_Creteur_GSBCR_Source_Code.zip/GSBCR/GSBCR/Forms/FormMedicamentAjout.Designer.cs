﻿
namespace GSBCR.Forms
{
    partial class FormMedicamentAjout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDepotLegal = new System.Windows.Forms.Label();
            this.lblNomCommercial = new System.Windows.Forms.Label();
            this.lblFamille = new System.Windows.Forms.Label();
            this.lblComposition = new System.Windows.Forms.Label();
            this.lblEffets = new System.Windows.Forms.Label();
            this.lblContreIndication = new System.Windows.Forms.Label();
            this.lblPrix = new System.Windows.Forms.Label();
            this.txtDepotLegal = new System.Windows.Forms.TextBox();
            this.txtContreIndication = new System.Windows.Forms.TextBox();
            this.txtComposition = new System.Windows.Forms.TextBox();
            this.txtPrixEchantillion = new System.Windows.Forms.TextBox();
            this.txtEffets = new System.Windows.Forms.TextBox();
            this.txtNomCommercial = new System.Windows.Forms.TextBox();
            this.lblPharmacopee = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.cboFamille = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblDepotLegal
            // 
            this.lblDepotLegal.AutoSize = true;
            this.lblDepotLegal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepotLegal.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDepotLegal.Location = new System.Drawing.Point(274, 194);
            this.lblDepotLegal.Name = "lblDepotLegal";
            this.lblDepotLegal.Size = new System.Drawing.Size(205, 30);
            this.lblDepotLegal.TabIndex = 0;
            this.lblDepotLegal.Text = "DEPOT LEGAL :";
            // 
            // lblNomCommercial
            // 
            this.lblNomCommercial.AutoSize = true;
            this.lblNomCommercial.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomCommercial.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblNomCommercial.Location = new System.Drawing.Point(274, 230);
            this.lblNomCommercial.Name = "lblNomCommercial";
            this.lblNomCommercial.Size = new System.Drawing.Size(270, 30);
            this.lblNomCommercial.TabIndex = 1;
            this.lblNomCommercial.Text = "NOM COMMERCIAL :";
            // 
            // lblFamille
            // 
            this.lblFamille.AutoSize = true;
            this.lblFamille.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFamille.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblFamille.Location = new System.Drawing.Point(274, 264);
            this.lblFamille.Name = "lblFamille";
            this.lblFamille.Size = new System.Drawing.Size(133, 30);
            this.lblFamille.TabIndex = 2;
            this.lblFamille.Text = "FAMILLE :";
            // 
            // lblComposition
            // 
            this.lblComposition.AutoSize = true;
            this.lblComposition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComposition.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblComposition.Location = new System.Drawing.Point(271, 393);
            this.lblComposition.Name = "lblComposition";
            this.lblComposition.Size = new System.Drawing.Size(209, 30);
            this.lblComposition.TabIndex = 3;
            this.lblComposition.Text = "COMPOSITION :";
            // 
            // lblEffets
            // 
            this.lblEffets.AutoSize = true;
            this.lblEffets.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEffets.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblEffets.Location = new System.Drawing.Point(274, 303);
            this.lblEffets.Name = "lblEffets";
            this.lblEffets.Size = new System.Drawing.Size(126, 30);
            this.lblEffets.TabIndex = 4;
            this.lblEffets.Text = "EFFETS :";
            // 
            // lblContreIndication
            // 
            this.lblContreIndication.AutoSize = true;
            this.lblContreIndication.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContreIndication.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblContreIndication.Location = new System.Drawing.Point(271, 483);
            this.lblContreIndication.Name = "lblContreIndication";
            this.lblContreIndication.Size = new System.Drawing.Size(220, 30);
            this.lblContreIndication.TabIndex = 5;
            this.lblContreIndication.Text = "CONTRE INDIC. :";
            // 
            // lblPrix
            // 
            this.lblPrix.AutoSize = true;
            this.lblPrix.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrix.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPrix.Location = new System.Drawing.Point(268, 573);
            this.lblPrix.Name = "lblPrix";
            this.lblPrix.Size = new System.Drawing.Size(273, 30);
            this.lblPrix.TabIndex = 6;
            this.lblPrix.Text = "PRIX ECHANTILLON :";
            // 
            // txtDepotLegal
            // 
            this.txtDepotLegal.Location = new System.Drawing.Point(556, 198);
            this.txtDepotLegal.MaxLength = 20;
            this.txtDepotLegal.Name = "txtDepotLegal";
            this.txtDepotLegal.Size = new System.Drawing.Size(578, 29);
            this.txtDepotLegal.TabIndex = 0;
            // 
            // txtContreIndication
            // 
            this.txtContreIndication.Location = new System.Drawing.Point(556, 486);
            this.txtContreIndication.MaxLength = 250;
            this.txtContreIndication.Multiline = true;
            this.txtContreIndication.Name = "txtContreIndication";
            this.txtContreIndication.Size = new System.Drawing.Size(578, 84);
            this.txtContreIndication.TabIndex = 5;
            // 
            // txtComposition
            // 
            this.txtComposition.Location = new System.Drawing.Point(556, 396);
            this.txtComposition.MaxLength = 250;
            this.txtComposition.Multiline = true;
            this.txtComposition.Name = "txtComposition";
            this.txtComposition.Size = new System.Drawing.Size(578, 84);
            this.txtComposition.TabIndex = 4;
            // 
            // txtPrixEchantillion
            // 
            this.txtPrixEchantillion.Location = new System.Drawing.Point(556, 576);
            this.txtPrixEchantillion.Name = "txtPrixEchantillion";
            this.txtPrixEchantillion.Size = new System.Drawing.Size(578, 29);
            this.txtPrixEchantillion.TabIndex = 6;
            // 
            // txtEffets
            // 
            this.txtEffets.Location = new System.Drawing.Point(556, 306);
            this.txtEffets.MaxLength = 250;
            this.txtEffets.Multiline = true;
            this.txtEffets.Name = "txtEffets";
            this.txtEffets.Size = new System.Drawing.Size(578, 84);
            this.txtEffets.TabIndex = 3;
            // 
            // txtNomCommercial
            // 
            this.txtNomCommercial.Location = new System.Drawing.Point(556, 232);
            this.txtNomCommercial.MaxLength = 50;
            this.txtNomCommercial.Name = "txtNomCommercial";
            this.txtNomCommercial.Size = new System.Drawing.Size(578, 29);
            this.txtNomCommercial.TabIndex = 1;
            // 
            // lblPharmacopee
            // 
            this.lblPharmacopee.AutoSize = true;
            this.lblPharmacopee.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPharmacopee.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPharmacopee.Location = new System.Drawing.Point(223, 52);
            this.lblPharmacopee.Name = "lblPharmacopee";
            this.lblPharmacopee.Size = new System.Drawing.Size(422, 70);
            this.lblPharmacopee.TabIndex = 15;
            this.lblPharmacopee.Text = "Pharmacopee";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(962, 687);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(172, 38);
            this.btnSave.TabIndex = 1000;
            this.btnSave.Text = "Enregistrer";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // cboFamille
            // 
            this.cboFamille.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFamille.FormattingEnabled = true;
            this.cboFamille.Location = new System.Drawing.Point(556, 267);
            this.cboFamille.Name = "cboFamille";
            this.cboFamille.Size = new System.Drawing.Size(578, 32);
            this.cboFamille.TabIndex = 2;
            // 
            // FormMedicamentAjout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(1277, 802);
            this.Controls.Add(this.cboFamille);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblPharmacopee);
            this.Controls.Add(this.txtNomCommercial);
            this.Controls.Add(this.txtEffets);
            this.Controls.Add(this.txtPrixEchantillion);
            this.Controls.Add(this.txtComposition);
            this.Controls.Add(this.txtContreIndication);
            this.Controls.Add(this.txtDepotLegal);
            this.Controls.Add(this.lblPrix);
            this.Controls.Add(this.lblContreIndication);
            this.Controls.Add(this.lblEffets);
            this.Controls.Add(this.lblComposition);
            this.Controls.Add(this.lblFamille);
            this.Controls.Add(this.lblNomCommercial);
            this.Controls.Add(this.lblDepotLegal);
            this.Name = "FormMedicamentAjout";
            this.Text = "FormMedicamentAjout";
            this.Load += new System.EventHandler(this.FormMedicamentAjout_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDepotLegal;
        private System.Windows.Forms.Label lblNomCommercial;
        private System.Windows.Forms.Label lblFamille;
        private System.Windows.Forms.Label lblComposition;
        private System.Windows.Forms.Label lblEffets;
        private System.Windows.Forms.Label lblContreIndication;
        private System.Windows.Forms.Label lblPrix;
        private System.Windows.Forms.TextBox txtDepotLegal;
        private System.Windows.Forms.TextBox txtContreIndication;
        private System.Windows.Forms.TextBox txtComposition;
        private System.Windows.Forms.TextBox txtPrixEchantillion;
        private System.Windows.Forms.TextBox txtEffets;
        private System.Windows.Forms.TextBox txtNomCommercial;
        private System.Windows.Forms.Label lblPharmacopee;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ComboBox cboFamille;
    }
}