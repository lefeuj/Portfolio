﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBCR.Forms
{
    public partial class FormLogin : Form
    {
        // On créé une variable pour le nombre d'essai et on l'initialise à 0
        int iTryConnection = 0;
        // On créé une variable pour le nombre d'essai maximum et on l'initialise à 0
        int iTryConnectionMax = 4;

        public FormLogin()
        {
            InitializeComponent();
        }

        // On créé une variable de résultat de connexion
        bool LoginSucces = false;

        private void BtnValidate_Click(object sender, EventArgs e)
        {
            try
            {
                // On créer une variable de connexion SQL
                SqlConnection con = new SqlConnection(Classes.Security.ConnectionString);
                // On ouvre la connexion
                con.Open();
                try
                {
                    //On initialise une variable de commande et on l'initialise avec la requête et la connexion
                    SqlCommand cmd = new SqlCommand("SELECT * FROM tbUser WHERE Login=@Login", con);
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@Login", this.txtLogin.Text));
                    // On créer une variable DataReader et on la rempli grâce à la commande
                    SqlDataReader dataReader = cmd.ExecuteReader();
                    // Tant qu'il y a des lignes
                    while (dataReader.Read())
                    {
                        // Si les mots de passe sont identiques
                        if ((string)dataReader["Password"] == this.txtPassword.Text)
                        {
                            LoginSucces = true;
                            // On initialise le "CurrentUser" avec les données du DataRow
                            Classes.Tools.CurrentUser = new Models.User()
                            {
                                Login = (string)dataReader["Login"],
                                Password = (string)dataReader["Password"],
                                Uid = (Guid)dataReader["Uid"],
                            };
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
                // On ferme la connexion
                con.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }

            // Si "LoginSucces" est vrai
            if (LoginSucces == true)
            {
                // On affecte le résultat de la boîte de dialogue à "OK"
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                // Si le nombre d'essai de connexion est supérieur ou égale à la variable maximale
                if (iTryConnection >= iTryConnectionMax)
                {
                    // On affiche le message d'erreur
                    MessageBox.Show("Vous avez atteint la limite de connexion", "GSBCR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    // On retourne
                    return;
                }
                // Sinon si le nombre d'essai de connexion est supérieur à 0
                else if (iTryConnection >= 0)
                {
                    // On affiche un message d'avertissement et on affiche le nombre d'essai restant
                    MessageBox.Show($"Login Failed ! Attention il vous reste  {(iTryConnectionMax - iTryConnection)}  essais", "GSBCR", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                // On incrémente la variable de 1
                iTryConnection = iTryConnection + 1;
            }
        }
    }
}
