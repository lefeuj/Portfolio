﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBCR.Forms
{
    public partial class FormMedicamentAjout : Form
    {
        public FormMedicamentAjout()
        {
            InitializeComponent();
        }
        private void BtnSave_Click(object sender, EventArgs e)
        {
            //On essaie
            try
            {
                //On initialise une variable de résultat et on l'initialise à 0
                int res = 0;
                //On initialise une variable de connexion et on l'initilise avec la variable statique
                SqlConnection connexion = new SqlConnection(Classes.Security.ConnectionString);
                //On ouvre la connexion
                connexion.Open();
                //On essaie
                try
                {
                    //On initialise une variable de commande et on l'initialise avec la requête et la connexion
                    SqlCommand cmd = new SqlCommand("INSERT INTO tbMedicament (" +
                        "DepotLegal" +
                        ",NomCommercial" +
                        ",FamilleCode" +
                        ",Composition" +
                        ",Effet" +
                        ",ContreIndication" +
                        ",PrixEchantillion" +
                        ") VALUES (" +
                        "@DepotLegal" +
                        ",@NomCommercial" +
                        ",@FamilleCode" +
                        ",@Composition" +
                        ",@Effet" +
                        ",@ContreIndication" +
                        ",@PrixEchantillion)", connexion);
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@DepotLegal", this.txtDepotLegal.Text));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@NomCommercial", this.txtNomCommercial.Text));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@FamilleCode", this.cboFamille.SelectedValue));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@Composition", this.txtComposition.Text));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@Effet", this.txtEffets.Text));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@ContreIndication", this.txtContreIndication.Text));
                    //On ajoute un paramètre SQL à la commande
                    cmd.Parameters.Add(new SqlParameter("@PrixEchantillion", this.txtPrixEchantillion.Text.Replace(',','.')));
                    //On initialise la variable de résultat avec le retour de l'execution de la commande
                    res = cmd.ExecuteNonQuery();
                }
                //Si cela présente une erreur on capture celle-ci
                catch(Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Erreur de commande : {ex.Message}");
                }
                //On ferme la connexion
                connexion.Close();
                //Si la variable de retour est égale à zéro enregistrement alors on affiche un message
                if (res == 0) { MessageBox.Show("Echec de l'enregistrement", "GSB", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                //Sinon on ferme le formulaire
                else { this.Close(); }
            }
            //Si cela présente une erreur on capture celle-ci
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Erreur de connection : {ex.Message}");
            }
        }

        private void FormMedicamentAjout_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlConnection = new SqlConnection(Classes.Security.ConnectionString);
                sqlConnection.Open();
                try
                {
                    string sQuery = "SELECT * FROM tbFamilleMedicament ";
                    SqlCommand sqlCommand = new SqlCommand(sQuery, sqlConnection);
                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                    List<Models.FamilleMedicament> maListe = new List<Models.FamilleMedicament>();
                    while (sqlDataReader.Read())
                    {
                        maListe.Add(new Models.FamilleMedicament()
                        {
                            Uid = (Guid)sqlDataReader["Uid"],
                            Code = (string)sqlDataReader["code"],
                            Libelle = (string)sqlDataReader["Libelle"]
                        });
                    };
                    cboFamille.DataSource = maListe;
                    cboFamille.DisplayMember = "Libelle";
                    cboFamille.ValueMember = "Code";
                }
                catch (Exception ex)
                {
                    Console.WriteLine("erreur de connection");
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("erreur de connection");
            }
        }
    }
}


