﻿
namespace GSBCR.Forms
{
    partial class FormGeneral
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuStripGeneral = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiQuit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCompteRendu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCompteRenduNouveau = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCompteRenduConsulter = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuConsulter = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiConsulterPraticiens = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAutresVisiteurs = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAutresVisiteursAjouter = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiMedicaments = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiMedicamentsConsulter = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiMedicamentsAjouter = new System.Windows.Forms.ToolStripMenuItem();
            this.stStripGeneral = new System.Windows.Forms.StatusStrip();
            this.toolStripSociety = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsmiAutresVisiteursConsulter = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuStripGeneral.SuspendLayout();
            this.stStripGeneral.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuStripGeneral
            // 
            this.mnuStripGeneral.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuStripGeneral.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuCompteRendu,
            this.mnuConsulter});
            this.mnuStripGeneral.Location = new System.Drawing.Point(0, 0);
            this.mnuStripGeneral.Name = "mnuStripGeneral";
            this.mnuStripGeneral.Padding = new System.Windows.Forms.Padding(8, 3, 0, 3);
            this.mnuStripGeneral.Size = new System.Drawing.Size(1067, 30);
            this.mnuStripGeneral.TabIndex = 0;
            this.mnuStripGeneral.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiQuit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(66, 24);
            this.mnuFile.Text = "&Fichier";
            // 
            // tsmiQuit
            // 
            this.tsmiQuit.Name = "tsmiQuit";
            this.tsmiQuit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.tsmiQuit.Size = new System.Drawing.Size(191, 26);
            this.tsmiQuit.Text = "&Quitter";
            this.tsmiQuit.Click += new System.EventHandler(this.TsmiQuit_Click);
            // 
            // mnuCompteRendu
            // 
            this.mnuCompteRendu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiCompteRenduNouveau,
            this.tsmiCompteRenduConsulter});
            this.mnuCompteRendu.Name = "mnuCompteRendu";
            this.mnuCompteRendu.Size = new System.Drawing.Size(124, 24);
            this.mnuCompteRendu.Text = "&Compte-Rendu";
            // 
            // tsmiCompteRenduNouveau
            // 
            this.tsmiCompteRenduNouveau.Name = "tsmiCompteRenduNouveau";
            this.tsmiCompteRenduNouveau.Size = new System.Drawing.Size(154, 26);
            this.tsmiCompteRenduNouveau.Text = "&Nouveau";
            this.tsmiCompteRenduNouveau.Click += new System.EventHandler(this.TsmiCompteRenduNouveau_Click);
            // 
            // tsmiCompteRenduConsulter
            // 
            this.tsmiCompteRenduConsulter.Name = "tsmiCompteRenduConsulter";
            this.tsmiCompteRenduConsulter.Size = new System.Drawing.Size(154, 26);
            this.tsmiCompteRenduConsulter.Text = "&Consulter";
            this.tsmiCompteRenduConsulter.Click += new System.EventHandler(this.TsmiCompteRenduConsulter_Click);
            // 
            // mnuConsulter
            // 
            this.mnuConsulter.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiConsulterPraticiens,
            this.tsmiAutresVisiteurs,
            this.tsmiMedicaments});
            this.mnuConsulter.Name = "mnuConsulter";
            this.mnuConsulter.Size = new System.Drawing.Size(85, 24);
            this.mnuConsulter.Text = "C&onsulter";
            // 
            // tsmiConsulterPraticiens
            // 
            this.tsmiConsulterPraticiens.Name = "tsmiConsulterPraticiens";
            this.tsmiConsulterPraticiens.Size = new System.Drawing.Size(224, 26);
            this.tsmiConsulterPraticiens.Text = "&Praticiens";
            this.tsmiConsulterPraticiens.Click += new System.EventHandler(this.TsmiConsulterPraticiens_Click);
            // 
            // tsmiAutresVisiteurs
            // 
            this.tsmiAutresVisiteurs.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiAutresVisiteursConsulter,
            this.tsmiAutresVisiteursAjouter});
            this.tsmiAutresVisiteurs.Name = "tsmiAutresVisiteurs";
            this.tsmiAutresVisiteurs.Size = new System.Drawing.Size(224, 26);
            this.tsmiAutresVisiteurs.Text = "&Visiteurs";
            // 
            // tsmiAutresVisiteursAjouter
            // 
            this.tsmiAutresVisiteursAjouter.Name = "tsmiAutresVisiteursAjouter";
            this.tsmiAutresVisiteursAjouter.Size = new System.Drawing.Size(224, 26);
            this.tsmiAutresVisiteursAjouter.Text = "&Ajouter";
            this.tsmiAutresVisiteursAjouter.Click += new System.EventHandler(this.TsmiAutresVisiteursAjouter_Click);
            // 
            // tsmiMedicaments
            // 
            this.tsmiMedicaments.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiMedicamentsConsulter,
            this.tsmiMedicamentsAjouter});
            this.tsmiMedicaments.Name = "tsmiMedicaments";
            this.tsmiMedicaments.Size = new System.Drawing.Size(224, 26);
            this.tsmiMedicaments.Text = "&Médicaments";
            // 
            // tsmiMedicamentsConsulter
            // 
            this.tsmiMedicamentsConsulter.Name = "tsmiMedicamentsConsulter";
            this.tsmiMedicamentsConsulter.Size = new System.Drawing.Size(224, 26);
            this.tsmiMedicamentsConsulter.Text = "&Consulter";
            this.tsmiMedicamentsConsulter.Click += new System.EventHandler(this.TsmiMedicamentsConsulter_Click);
            // 
            // tsmiMedicamentsAjouter
            // 
            this.tsmiMedicamentsAjouter.Name = "tsmiMedicamentsAjouter";
            this.tsmiMedicamentsAjouter.Size = new System.Drawing.Size(224, 26);
            this.tsmiMedicamentsAjouter.Text = "&Ajouter";
            this.tsmiMedicamentsAjouter.Click += new System.EventHandler(this.TsmiMedicamentsAjouter_Click);
            // 
            // stStripGeneral
            // 
            this.stStripGeneral.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.stStripGeneral.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSociety,
            this.toolStripMessage,
            this.toolStripSeparator,
            this.toolStripUser});
            this.stStripGeneral.Location = new System.Drawing.Point(0, 524);
            this.stStripGeneral.Name = "stStripGeneral";
            this.stStripGeneral.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.stStripGeneral.Size = new System.Drawing.Size(1067, 30);
            this.stStripGeneral.TabIndex = 2;
            this.stStripGeneral.Text = "statusStrip1";
            // 
            // toolStripSociety
            // 
            this.toolStripSociety.Name = "toolStripSociety";
            this.toolStripSociety.Size = new System.Drawing.Size(53, 24);
            this.toolStripSociety.Text = "GSB ©";
            // 
            // toolStripMessage
            // 
            this.toolStripMessage.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.toolStripMessage.Name = "toolStripMessage";
            this.toolStripMessage.Size = new System.Drawing.Size(17, 24);
            this.toolStripMessage.Text = " ";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(973, 24);
            this.toolStripSeparator.Spring = true;
            // 
            // toolStripUser
            // 
            this.toolStripUser.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.toolStripUser.Name = "toolStripUser";
            this.toolStripUser.Size = new System.Drawing.Size(4, 24);
            // 
            // tsmiAutresVisiteursConsulter
            // 
            this.tsmiAutresVisiteursConsulter.Name = "tsmiAutresVisiteursConsulter";
            this.tsmiAutresVisiteursConsulter.Size = new System.Drawing.Size(224, 26);
            this.tsmiAutresVisiteursConsulter.Text = "&Consulter";
            this.tsmiAutresVisiteursConsulter.Click += new System.EventHandler(this.TsmiAutresVisiteursConsulter_Click);
            // 
            // FormGeneral
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.stStripGeneral);
            this.Controls.Add(this.mnuStripGeneral);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormGeneral";
            this.Text = "Gestion des comptes rendus";
            this.Load += new System.EventHandler(this.FormGeneral_Load);
            this.mnuStripGeneral.ResumeLayout(false);
            this.mnuStripGeneral.PerformLayout();
            this.stStripGeneral.ResumeLayout(false);
            this.stStripGeneral.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuStripGeneral;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuCompteRendu;
        private System.Windows.Forms.ToolStripMenuItem tsmiQuit;
        private System.Windows.Forms.ToolStripMenuItem tsmiCompteRenduNouveau;
        private System.Windows.Forms.ToolStripMenuItem tsmiCompteRenduConsulter;
        private System.Windows.Forms.ToolStripMenuItem mnuConsulter;
        private System.Windows.Forms.ToolStripMenuItem tsmiMedicamentsConsulter;
        private System.Windows.Forms.ToolStripMenuItem tsmiConsulterPraticiens;
        private System.Windows.Forms.StatusStrip stStripGeneral;
        private System.Windows.Forms.ToolStripStatusLabel toolStripSociety;
        private System.Windows.Forms.ToolStripStatusLabel toolStripMessage;
        private System.Windows.Forms.ToolStripStatusLabel toolStripSeparator;
        private System.Windows.Forms.ToolStripStatusLabel toolStripUser;
        private System.Windows.Forms.ToolStripMenuItem tsmiMedicaments;
        private System.Windows.Forms.ToolStripMenuItem tsmiMedicamentsAjouter;
        private System.Windows.Forms.ToolStripMenuItem tsmiAutresVisiteurs;
        private System.Windows.Forms.ToolStripMenuItem tsmiAutresVisiteursAjouter;
        private System.Windows.Forms.ToolStripMenuItem tsmiAutresVisiteursConsulter;
    }
}