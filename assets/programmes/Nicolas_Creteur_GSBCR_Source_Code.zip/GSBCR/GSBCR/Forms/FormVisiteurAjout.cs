﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBCR.Forms
{
    public partial class FormVisiteurAjout : Form
    {
        public FormVisiteurAjout()
        {
            InitializeComponent();
            //this.dtpDateEmbauche.Value = DateTime.Now;
            //---------------
        }

        private void btnNext_Click(object sender, EventArgs e)
        {

            int res = 0;
            // On essaie d'ouvrir la connection
            try
            {
                //On crée une variable de conction relier à la db
                SqlConnection connection = new SqlConnection(Classes.Security.ConnectionString);
                //requrette Sql pour inseret les variable nommé "@..."
                string query = "INSERT INTO tbVisiteur (Matricule, Departement, Nom, Prenom, Adresse, CodePostal, Ville, DateEmbauche, Secteur, Laboratoire) " +
                    "VALUES " +
                    "(@txtMatricule, @cboDepartement, @txtName, @txtLastname, @txtAdress, @txtCP, @txtCyti, @dtpDateEmbauche, @txtSecteur, @txtLaboratoire)";
                //on crée un commande SQL et on lui passe on passe parrametre la requette et la connection 
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@txtMatricule", (string)txtMatricule.Text);
                    command.Parameters.AddWithValue("@cboDepartement", (string)Cbodepartement.SelectedValue);
                    command.Parameters.AddWithValue("@txtName", (string)txtName.Text);
                    command.Parameters.AddWithValue("@txtLastname", (string)txtLastname.Text);
                    command.Parameters.AddWithValue("@txtAdress", (string)txtAddress.Text);
                    command.Parameters.AddWithValue("@txtCP", (string)txtCP.Text);
                    command.Parameters.AddWithValue("@txtCyti", (string)txtCyti.Text);
                    command.Parameters.AddWithValue("@dtpDateEmbauche", dtpDateEmbauche.Value);
                    command.Parameters.AddWithValue("@txtSecteur", (string)txtSecteur.Text);
                    command.Parameters.AddWithValue("@txtLaboratoire", (string)txtLauboratoire.Text);
                    res = command.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("Error Generated. Details: " + ex.ToString());
                }
                // On ferme la connexion
                connection.Close();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }

            if (res > 0) { this.Close(); }
            else { MessageBox.Show("Echec de l'enregistrement.", "GSB", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void FormVisiteurAjout_Load(object sender, EventArgs e)
        {
            Cbodepartement.DataSource = Models.Departements.GetDepartements();
            Cbodepartement.DisplayMember = "Nom";
            Cbodepartement.ValueMember = "Code";
        }

    }
}
