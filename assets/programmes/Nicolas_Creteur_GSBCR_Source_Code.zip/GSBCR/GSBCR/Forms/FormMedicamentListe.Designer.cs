﻿
namespace GSBCR.Forms
{
    partial class FormMedicamentListe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMedicamentListe));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnRefresh = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAjouter = new System.Windows.Forms.ToolStripButton();
            this.dgvListCol = new System.Windows.Forms.DataGridView();
            this.dgvListColDepot = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColNom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColFamille = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColPrix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bdsList = new System.Windows.Forms.BindingSource(this.components);
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListCol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsList)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnRefresh,
            this.toolStripSeparator1,
            this.btnAjouter});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1067, 27);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(72, 24);
            this.btnRefresh.Text = "Rafraîchir";
            this.btnRefresh.Click += new System.EventHandler(this.BtnRefresh_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // btnAjouter
            // 
            this.btnAjouter.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnAjouter.Image = ((System.Drawing.Image)(resources.GetObject("btnAjouter.Image")));
            this.btnAjouter.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(62, 24);
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.Click += new System.EventHandler(this.BtnAjouter_Click);
            // 
            // dgvListCol
            // 
            this.dgvListCol.AllowUserToAddRows = false;
            this.dgvListCol.AllowUserToDeleteRows = false;
            this.dgvListCol.AutoGenerateColumns = false;
            this.dgvListCol.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListCol.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvListColDepot,
            this.dgvListColNom,
            this.dgvListColFamille,
            this.dgvListColPrix});
            this.dgvListCol.DataSource = this.bdsList;
            this.dgvListCol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvListCol.Location = new System.Drawing.Point(0, 27);
            this.dgvListCol.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvListCol.Name = "dgvListCol";
            this.dgvListCol.ReadOnly = true;
            this.dgvListCol.RowHeadersWidth = 51;
            this.dgvListCol.Size = new System.Drawing.Size(1067, 527);
            this.dgvListCol.TabIndex = 1;
            // 
            // dgvListColDepot
            // 
            this.dgvListColDepot.DataPropertyName = "DepotLegal";
            this.dgvListColDepot.HeaderText = "Dépôt";
            this.dgvListColDepot.MinimumWidth = 6;
            this.dgvListColDepot.Name = "dgvListColDepot";
            this.dgvListColDepot.ReadOnly = true;
            this.dgvListColDepot.Width = 125;
            // 
            // dgvListColNom
            // 
            this.dgvListColNom.DataPropertyName = "NomCommercial";
            this.dgvListColNom.HeaderText = "Nom";
            this.dgvListColNom.MinimumWidth = 6;
            this.dgvListColNom.Name = "dgvListColNom";
            this.dgvListColNom.ReadOnly = true;
            this.dgvListColNom.Width = 125;
            // 
            // dgvListColFamille
            // 
            this.dgvListColFamille.DataPropertyName = "Famille";
            this.dgvListColFamille.HeaderText = "Famille";
            this.dgvListColFamille.MinimumWidth = 6;
            this.dgvListColFamille.Name = "dgvListColFamille";
            this.dgvListColFamille.ReadOnly = true;
            this.dgvListColFamille.Width = 125;
            // 
            // dgvListColPrix
            // 
            this.dgvListColPrix.DataPropertyName = "PrixEchantillion";
            dataGridViewCellStyle1.Format = "C2";
            dataGridViewCellStyle1.NullValue = null;
            this.dgvListColPrix.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvListColPrix.HeaderText = "Prix";
            this.dgvListColPrix.MinimumWidth = 6;
            this.dgvListColPrix.Name = "dgvListColPrix";
            this.dgvListColPrix.ReadOnly = true;
            this.dgvListColPrix.Width = 125;
            // 
            // FormMedicamentListe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.dgvListCol);
            this.Controls.Add(this.toolStrip1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormMedicamentListe";
            this.Text = "Liste Médicament";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListCol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel btnRefresh;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnAjouter;
        private System.Windows.Forms.DataGridView dgvListCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColDepot;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColNom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColFamille;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColPrix;
        private System.Windows.Forms.BindingSource bdsList;
    }
}