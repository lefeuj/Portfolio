﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GSBCR.Models;

namespace GSBCR.Forms
{
    public partial class FormVisiteurListe : Form
    {
        public FormVisiteurListe()
        {
            InitializeComponent();
            this.dgvListCol.AutoGenerateColumns = false;
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection(Classes.Security.ConnectionString);
            sqlConnection.Open();
            try
            {
                string sQuery = "SELECT * FROM tbVisiteur";
                SqlCommand sqlCommand = new SqlCommand(sQuery, sqlConnection);
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                List<Visiteur> visiteurs = new List<Visiteur>();
                while (sqlDataReader.Read())
                {
                    Visiteur visiteur = new Visiteur()
                    {
                        Uid = (Guid)sqlDataReader["Uid"],
                        Matricule = (string)sqlDataReader["Matricule"],
                        Departement = (string)sqlDataReader["Departement"],
                        Nom = (string)sqlDataReader["Nom"],
                        Prenom = (string)sqlDataReader["Prenom"],
                        Adresse = (string)sqlDataReader["Adresse"],
                        CodePostal = (string)sqlDataReader["CodePostal"],
                        Ville = (string)sqlDataReader["Ville"],
                        DateEmbauche = (DateTime)sqlDataReader["DateEmbauche"],
                        Secteur = (string)sqlDataReader["Secteur"],
                        Laboratoire = (string)sqlDataReader["Laboratoire"]
                    };
                    visiteurs.Add(visiteur);
                }
                this.dgvListCol.DataSource = visiteurs;
                this.dgvListCol.Refresh();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            sqlConnection.Close();
        }

        private void BtnAjouter_Click(object sender, EventArgs e)
        {
            Forms.FormVisiteurAjout form = new Forms.FormVisiteurAjout();
            form.MdiParent = this.MdiParent;
            form.Show();
        }
    }
    
}
