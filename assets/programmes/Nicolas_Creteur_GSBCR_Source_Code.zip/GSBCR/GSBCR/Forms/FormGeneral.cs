﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBCR.Forms
{
    public partial class FormGeneral : Form
    {
        public FormGeneral()
        {
            InitializeComponent();
        }

        private void FormGeneral_Load(object sender, EventArgs e)
        {
            this.toolStripUser.Text = $"{Classes.Tools.CurrentUser.Login}";
        }

        private void TsmiQuit_Click(object sender, EventArgs e)
        {

        }

        //-----------------------------------------------//
        //----    Comptes-Rendus                     ----//
        private void TsmiCompteRenduNouveau_Click(object sender, EventArgs e)
        {
            Forms.FormCompteRenduAjout form = new FormCompteRenduAjout();
            form.MdiParent = this;
            form.Show();
        }
        private void TsmiCompteRenduConsulter_Click(object sender, EventArgs e)
        {
            Forms.FormCompteRenduListe form = new FormCompteRenduListe();
            form.MdiParent = this;
            form.Show();
        }
        //-----------------------------------------------//

        //-----------------------------------------------//
        //----    Praticiens                         ----//
        private void TsmiConsulterPraticiens_Click(object sender, EventArgs e)
        {
            Forms.FormPraticienListe form = new FormPraticienListe();
            form.MdiParent = this;
            form.Show();
        }
        //-----------------------------------------------//

        //-----------------------------------------------//
        //----    Médicaments                        ----//
        private void TsmiMedicamentsConsulter_Click(object sender, EventArgs e)
        {
            Forms.FormMedicamentListe form = new FormMedicamentListe();
            form.MdiParent = this;
            form.Show();
        }
        private void TsmiMedicamentsAjouter_Click(object sender, EventArgs e)
        {
            Forms.FormMedicamentAjout form = new FormMedicamentAjout();
            form.MdiParent = this;
            form.Show();
        }
        //-----------------------------------------------//

        //-----------------------------------------------//
        //----    Autres Visiteurs                   ----//
        private void TsmiAutresVisiteursConsulter_Click(object sender, EventArgs e)
        {
            Forms.FormVisiteurListe form = new FormVisiteurListe();
            form.MdiParent = this;
            form.Show();
        }
        private void TsmiAutresVisiteursAjouter_Click(object sender, EventArgs e)
        {
            Forms.FormVisiteurAjout form = new FormVisiteurAjout();
            form.MdiParent = this;
            form.Show();
        }
        //-----------------------------------------------//

        public void SetMessage(string text) { this.toolStripMessage.Text = text; }
    }
}
