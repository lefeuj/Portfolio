﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBCR.Forms
{
    public partial class FormMedicamentListe : Form
    {
        public FormMedicamentListe()
        {
            InitializeComponent();
        }
        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            List<Models.Medicament> medicaments = new List<Models.Medicament>();
            try
            {
                SqlConnection con = new SqlConnection(Classes.Security.ConnectionString);
                con.Open();
                try
                {
                    string query = $"SELECT * FROM tbMedicament";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Models.Medicament medicament = new Models.Medicament();
                            medicament.Uid = (Guid)reader["Uid"];
                            medicament.DepotLegal = (string)reader["DepotLegal"];
                            medicament.NomCommercial = (string)reader["NomCommercial"];
                            medicament.Famille = (string)reader["FamilleCode"];
                            medicament.Effet = (string)reader["Effet"];
                            medicament.Composition = (string)reader["Composition"];
                            medicament.ContreIndication = (string)reader["ContreIndication"];
                            medicament.PrixEchantillion = (double)reader["PrixEchantillion"];
                            medicaments.Add(medicament);
                        }
                    }
                }
                catch (Exception ex) {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
                con.Close();
            }
            catch (Exception ex) {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            this.bdsList.DataSource = medicaments;
        }
        private void BtnAjouter_Click(object sender, EventArgs e)
        {
            Forms.FormMedicamentAjout form = new FormMedicamentAjout();
            form.MdiParent = this.MdiParent;
            form.Show();
        }
    }
}
