#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      niko
#
# Created:     10/02/2021
# Copyright:   (c) niko 2021
# Licence:     <your licence>
#----------------------------------------------------------------------------

PossiblePalindrome = input ("merci de saisir une chaine de caracteres:")
x=-1
Pp=PossiblePalindrome
for i in Pp:
    if (i) != (Pp[x]):
        print("cette chaine de caracteres n'est pas un Palindrome")
        exit();
    x -= 1;
print("cette chaine de caracteres est un Palindrome")